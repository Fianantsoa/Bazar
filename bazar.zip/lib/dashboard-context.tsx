'use client'

import { createContext, useContext, useState, ReactNode } from 'react'

type Page = 'overview' | 'orders' | 'products' | 'analytics' | 'notifications' | 'settings'

interface DashboardContextType {
  currentPage: Page
  setCurrentPage: (page: Page) => void
  sidebarOpen: boolean
  setSidebarOpen: (open: boolean) => void
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined)

export function DashboardProvider({ children }: { children: ReactNode }) {
  const [currentPage, setCurrentPage] = useState<Page>('overview')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <DashboardContext.Provider value={{ currentPage, setCurrentPage, sidebarOpen, setSidebarOpen }}>
      {children}
    </DashboardContext.Provider>
  )
}

export function useDashboard() {
  const context = useContext(DashboardContext)
  if (!context) {
    throw new Error('useDashboard must be used within DashboardProvider')
  }
  return context
}
