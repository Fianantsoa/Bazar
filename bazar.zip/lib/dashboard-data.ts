// Types
export interface Order {
  id: string
  name: string
  product: string
  phone: string
  amount: string
  status: OrderStatus
  date: string
}

export type OrderStatus = 'Nouvelle' | 'Confirmée' | 'En livraison' | 'Livrée' | 'Annulée'

export interface Product {
  name: string
  category: string
  price: string
  stock: number
  status: ProductStatus
  link: string
}

export type ProductStatus = 'Disponible' | 'Rupture' | 'Archivé'

export interface Notification {
  id: string
  type: 'order' | 'stock' | 'delivery'
  title: string
  description: string
  time: string
}

// Mock Data
export const orders: Order[] = [
  { id: '#0042', name: 'Lalaina Rakoto', product: 'Robe Fleurie × 2', phone: '034 12 345 67', amount: '50 000 Ar', status: 'Nouvelle', date: '31 mai' },
  { id: '#0041', name: 'Haingotiana R.', product: 'Escarpin Noir 38', phone: '033 87 654 32', amount: '35 000 Ar', status: 'Confirmée', date: '31 mai' },
  { id: '#0040', name: 'Mirana Rasendra', product: 'Sac Cuir Caramel', phone: '032 55 111 22', amount: '45 000 Ar', status: 'En livraison', date: '30 mai' },
  { id: '#0039', name: 'Voahangy Andria', product: 'Collier Doré', phone: '034 77 888 99', amount: '12 000 Ar', status: 'Livrée', date: '30 mai' },
  { id: '#0038', name: 'Sandrine Razafy', product: 'Ensemble Wax L', phone: '033 22 333 44', amount: '55 000 Ar', status: 'Livrée', date: '29 mai' },
  { id: '#0037', name: 'Bakoly R.', product: 'Robe Fleurie × 1', phone: '032 66 777 88', amount: '25 000 Ar', status: 'Annulée', date: '29 mai' },
]

export const products: Product[] = [
  { name: 'Robe Fleurie', category: 'Robes', price: '25 000 Ar', stock: 1, status: 'Disponible', link: 'bazar.app/p/rF3k1' },
  { name: 'Sac Cuir Caramel', category: 'Sacs', price: '45 000 Ar', stock: 0, status: 'Rupture', link: 'bazar.app/p/sC9m2' },
  { name: 'Escarpin Noir 38', category: 'Chaussures', price: '35 000 Ar', stock: 8, status: 'Disponible', link: 'bazar.app/p/eN7p3' },
  { name: 'Collier Doré', category: 'Bijoux', price: '12 000 Ar', stock: 15, status: 'Disponible', link: 'bazar.app/p/cD2x4' },
  { name: 'Ensemble Wax L', category: 'Ensembles', price: '55 000 Ar', stock: 2, status: 'Disponible', link: 'bazar.app/p/eW5j5' },
  { name: 'Bracelet Argent', category: 'Bijoux', price: '8 500 Ar', stock: 20, status: 'Disponible', link: 'bazar.app/p/bA1k6' },
]

export const notifications: Notification[] = [
  { id: '1', type: 'order', title: 'Nouvelle commande — Robe Fleurie × 2', description: 'Lalaina Rakoto — il y a 5 min', time: '5 min' },
  { id: '2', type: 'stock', title: 'Alerte stock — Sac Cuir Caramel', description: 'Stock à 0 — rupture détectée — il y a 1h', time: '1h' },
  { id: '3', type: 'order', title: 'Nouvelle commande — Escarpin 38', description: 'Haingotiana R. — il y a 2h', time: '2h' },
  { id: '4', type: 'delivery', title: 'Commande livrée confirmée', description: 'Sandrine R. — Ensemble Wax L — il y a 3h', time: '3h' },
  { id: '5', type: 'stock', title: 'Alerte stock — Robe Fleurie Taille M', description: 'Stock à 1 — seuil minimum atteint — il y a 5h', time: '5h' },
]

export const chartData = [
  { day: 'L', orders: 6 },
  { day: 'M', orders: 10 },
  { day: 'Me', orders: 8 },
  { day: 'J', orders: 12 },
  { day: 'V', orders: 9 },
  { day: 'S', orders: 13 },
  { day: 'D', orders: 14 },
]

export const trafficSources = [
  { name: 'Facebook', percentage: 52, clicks: 2507, color: '#1877F2' },
  { name: 'WhatsApp', percentage: 31, clicks: 1495, color: '#25D366' },
  { name: 'TikTok', percentage: 12, clicks: 579, color: '#010101' },
  { name: 'Direct', percentage: 5, clicks: 241, color: '#F5A623' },
]

export const topProducts = [
  { name: 'Robe Fleurie', views: 389 },
  { name: 'Sac Cuir Caramel', views: 241 },
  { name: 'Escarpin Noir 38', views: 198 },
  { name: 'Collier Doré', views: 156 },
  { name: 'Ensemble Wax L', views: 134 },
]

export const stockAlerts = [
  { name: 'Robe Fleurie Taille M', stock: 1 },
  { name: 'Sac Cuir Caramel', stock: 0 },
  { name: 'Chaussures Escarpin 38', stock: 2 },
]

// Utility functions
export function getStatusColor(status: OrderStatus) {
  const colors: Record<OrderStatus, { bg: string; text: string }> = {
    'Nouvelle': { bg: 'bg-emerald-100', text: 'text-emerald-700' },
    'Confirmée': { bg: 'bg-blue-100', text: 'text-blue-700' },
    'En livraison': { bg: 'bg-amber-100', text: 'text-amber-700' },
    'Livrée': { bg: 'bg-teal-100', text: 'text-teal-700' },
    'Annulée': { bg: 'bg-red-100', text: 'text-red-700' },
  }
  return colors[status]
}

export function getProductStatusColor(status: ProductStatus) {
  const colors: Record<ProductStatus, { bg: string; text: string }> = {
    'Disponible': { bg: 'bg-emerald-100', text: 'text-emerald-700' },
    'Rupture': { bg: 'bg-red-100', text: 'text-red-700' },
    'Archivé': { bg: 'bg-stone-100', text: 'text-stone-600' },
  }
  return colors[status]
}

export function getInitials(name: string) {
  return name
    .split(' ')
    .map(word => word[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()
}

export function sendWhatsAppMessage(name: string, product: string, amount: string) {
  const msg = encodeURIComponent(
    `Bonjour ${name}, votre commande "${product}" d'un montant de ${amount} a été confirmée. Merci de votre confiance ! — Rova Fashions`
  )
  window.open(`https://wa.me/?text=${msg}`)
}
