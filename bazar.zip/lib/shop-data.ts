export interface Product {
  id: number
  name: string
  category: string
  price: number
  oldPrice?: number
  image?: string
  status: 'available' | 'rupture'
  description?: string
}

export interface Shop {
  name: string
  slug: string
  description: string
  avatar: string
  location: string
  responseTime: string
  whatsapp: string
  deliveryAvailable: boolean
  categories: string[]
  products: Product[]
}

// Exemple de boutique
export const DEMO_SHOP: Shop = {
  name: 'Chez Nadia Mode',
  slug: 'nadia-mode',
  description: 'Robes Wax, tenues tendance et accessoires. Commandez facilement, livraison a Antananarivo.',
  avatar: 'N',
  location: 'Antananarivo',
  responseTime: "moins d'1h",
  whatsapp: '261340000000',
  deliveryAvailable: true,
  categories: ['Robes', 'Hauts', 'Accessoires', 'Chaussures', 'Beaute'],
  products: [
    { id: 1, name: 'Robe Wax Ankara bleue', category: 'Robes', price: 85000, status: 'available' },
    { id: 2, name: 'Robe longue batik rouge', category: 'Robes', price: 95000, oldPrice: 110000, status: 'available' },
    { id: 3, name: 'Haut brode blanc casse', category: 'Hauts', price: 42000, status: 'available' },
    { id: 4, name: 'Top en lin naturel', category: 'Hauts', price: 38000, status: 'available' },
    { id: 5, name: 'Sac raphia tresse naturel', category: 'Accessoires', price: 28000, status: 'available' },
    { id: 6, name: 'Collier perles de bois', category: 'Accessoires', price: 15000, status: 'available' },
    { id: 7, name: 'Sandales cuir fauve', category: 'Chaussures', price: 65000, status: 'rupture' },
    { id: 8, name: 'Mules dorees', category: 'Chaussures', price: 55000, status: 'available' },
    { id: 9, name: 'Creme karite pur', category: 'Beaute', price: 12000, status: 'available' },
    { id: 10, name: 'Huile de coco artisanale', category: 'Beaute', price: 9000, status: 'available' },
    { id: 11, name: 'Robe soiree violette', category: 'Robes', price: 120000, oldPrice: 145000, status: 'available' },
    { id: 12, name: 'Ceinture Wax coloree', category: 'Accessoires', price: 18000, status: 'available' },
  ]
}

export function formatPrice(price: number): string {
  return price.toLocaleString('fr-MG') + ' Ar'
}
