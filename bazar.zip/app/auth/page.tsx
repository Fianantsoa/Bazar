import { AuthSidebar, AuthForm } from "@/components/auth"

export default function AuthPage() {
  return (
    <div className="flex min-h-screen">
      {/* Left Panel - Hidden on mobile */}
      <div className="hidden lg:flex lg:w-1/2">
        <AuthSidebar />
      </div>

      {/* Right Panel - Form */}
      <div className="flex flex-1 items-center justify-center bg-background p-6 lg:p-8">
        <AuthForm />
      </div>
    </div>
  )
}
