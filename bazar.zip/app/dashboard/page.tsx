'use client'

import { useState } from 'react'
import { DashboardProvider, useDashboard } from '@/lib/dashboard-context'
import { 
  Sidebar, 
  Topbar, 
  OverviewPage, 
  OrdersPage, 
  ProductsPage, 
  AnalyticsPage, 
  NotificationsPage, 
  SettingsPage 
} from '@/components/dashboard'

function DashboardContent() {
  const { currentPage, setCurrentPage } = useDashboard()
  const [showProductModal, setShowProductModal] = useState(false)

  const handleAddProduct = () => {
    setCurrentPage('products')
    // Small delay to ensure page switches before modal opens
    setTimeout(() => setShowProductModal(true), 100)
  }

  return (
    <div className="flex h-screen bg-[#F5F5F0]">
      <Sidebar />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Topbar onAddProduct={handleAddProduct} />
        
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {currentPage === 'overview' && <OverviewPage />}
          {currentPage === 'orders' && <OrdersPage />}
          {currentPage === 'products' && <ProductsPage onAddProduct={() => setShowProductModal(false)} />}
          {currentPage === 'analytics' && <AnalyticsPage />}
          {currentPage === 'notifications' && <NotificationsPage />}
          {currentPage === 'settings' && <SettingsPage />}
        </main>
      </div>
    </div>
  )
}

export default function DashboardPage() {
  return (
    <DashboardProvider>
      <DashboardContent />
    </DashboardProvider>
  )
}
