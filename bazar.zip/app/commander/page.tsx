"use client"

import { useState } from "react"
import { Check } from "lucide-react"
import { OrderHeader } from "@/components/order-form/header"
import { ProductRecap } from "@/components/order-form/product-recap"
import { VariantSelector } from "@/components/order-form/variant-selector"
import { QuantitySelector } from "@/components/order-form/quantity-selector"
import { CustomerForm } from "@/components/order-form/customer-form"
import { OrderSummary } from "@/components/order-form/order-summary"
import { SuccessScreen } from "@/components/order-form/success-screen"

const PRODUCT = {
  name: "Robe Élégante Fleurie",
  price: 45000,
  shop: "Boutique Miora Style",
  stock: 10,
}

const SIZE_OPTIONS = [
  { value: "XS", label: "XS" },
  { value: "S", label: "S" },
  { value: "M", label: "M" },
  { value: "L", label: "L" },
  { value: "XL", label: "XL" },
]

const COLOR_OPTIONS = [
  { value: "rose", label: "Rose" },
  { value: "blanc", label: "Blanc" },
  { value: "bleu-marine", label: "Bleu marine" },
]

interface FormErrors {
  name?: string
  phone?: string
  address?: string
}

export default function OrderFormPage() {
  const [submitted, setSubmitted] = useState(false)
  const [orderRef, setOrderRef] = useState("")

  // Variants
  const [selectedSize, setSelectedSize] = useState("S")
  const [selectedColor, setSelectedColor] = useState("rose")
  const [quantity, setQuantity] = useState(1)

  // Customer info
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    phone: "",
    address: "",
    note: "",
  })
  const [errors, setErrors] = useState<FormErrors>({})

  const handleCustomerChange = (field: string, value: string) => {
    setCustomerInfo((prev) => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {}

    if (!customerInfo.name.trim()) {
      newErrors.name = "Veuillez entrer votre nom complet."
    }
    if (!customerInfo.phone.trim()) {
      newErrors.phone = "Veuillez entrer un numéro valide."
    }
    if (!customerInfo.address.trim()) {
      newErrors.address = "Veuillez entrer votre adresse."
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = () => {
    if (!validateForm()) return

    const ref = "#BZR-" + Math.floor(10000 + Math.random() * 90000)
    setOrderRef(ref)
    setSubmitted(true)
  }

  const handleWhatsAppContact = () => {
    const sizeLabel = SIZE_OPTIONS.find((s) => s.value === selectedSize)?.label
    const colorLabel = COLOR_OPTIONS.find((c) => c.value === selectedColor)?.label
    const msg = encodeURIComponent(
      `Bonjour, j'ai passé commande sur Bazar.\nRéf : ${orderRef}\nNom : ${customerInfo.name}\nTél : ${customerInfo.phone}\nAdresse : ${customerInfo.address}\nProduit : ${PRODUCT.name} (${sizeLabel}, ${colorLabel}) × ${quantity}`
    )
    window.open(`https://wa.me/261340000000?text=${msg}`, "_blank")
  }

  const sizeLabel = SIZE_OPTIONS.find((s) => s.value === selectedSize)?.label
  const colorLabel = COLOR_OPTIONS.find((c) => c.value === selectedColor)?.label
  const articleDescription = `Robe (${sizeLabel}, ${colorLabel})`

  if (submitted) {
    return (
      <div className="min-h-screen bg-background">
        <OrderHeader />
        <SuccessScreen
          orderRef={orderRef}
          shopName={PRODUCT.shop}
          onContactWhatsApp={handleWhatsAppContact}
        />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      <OrderHeader />
      <ProductRecap name={PRODUCT.name} price={PRODUCT.price} shop={PRODUCT.shop} />

      <main className="mx-auto max-w-lg px-4">
        {/* Variants Section */}
        <section aria-labelledby="variants-heading">
          <h2 id="variants-heading" className="sr-only">
            Sélection des variantes
          </h2>
          <p className="pb-2 pt-5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Variante
          </p>
          <div className="overflow-hidden rounded-xl border border-border bg-card px-4">
            <VariantSelector
              label="Taille"
              options={SIZE_OPTIONS}
              value={selectedSize}
              onChange={setSelectedSize}
            />
            <div className="border-t border-border" />
            <VariantSelector
              label="Couleur"
              options={COLOR_OPTIONS}
              value={selectedColor}
              onChange={setSelectedColor}
            />
          </div>
        </section>

        {/* Quantity Section */}
        <section aria-labelledby="quantity-heading">
          <h2 id="quantity-heading" className="sr-only">
            Quantité
          </h2>
          <p className="pb-2 pt-5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Quantité
          </p>
          <div className="overflow-hidden rounded-xl border border-border bg-card px-4">
            <QuantitySelector value={quantity} max={PRODUCT.stock} onChange={setQuantity} />
          </div>
        </section>

        {/* Customer Info Section */}
        <section aria-labelledby="customer-heading">
          <h2 id="customer-heading" className="sr-only">
            Informations client
          </h2>
          <p className="pb-2 pt-5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Vos informations
          </p>
          <CustomerForm values={customerInfo} errors={errors} onChange={handleCustomerChange} />
        </section>

        {/* Order Summary Section */}
        <section aria-labelledby="summary-heading">
          <h2 id="summary-heading" className="sr-only">
            Récapitulatif de commande
          </h2>
          <p className="pb-2 pt-5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Récapitulatif
          </p>
          <OrderSummary
            articleDescription={articleDescription}
            unitPrice={PRODUCT.price}
            quantity={quantity}
          />
        </section>

        {/* Submit Section */}
        <section className="mt-6 flex flex-col gap-3" aria-labelledby="submit-heading">
          <h2 id="submit-heading" className="sr-only">
            Confirmer la commande
          </h2>
          <button
            type="button"
            onClick={handleSubmit}
            className="flex w-full items-center justify-center gap-2.5 rounded-xl bg-primary px-6 py-4 text-base font-semibold text-primary-foreground shadow-sm transition-all hover:bg-primary/90 active:scale-[0.98]"
          >
            <Check className="h-5 w-5" aria-hidden="true" />
            Confirmer ma commande
          </button>

          <div className="flex items-start gap-3 rounded-xl border border-accent/30 bg-accent/10 px-4 py-3.5">
            <div className="mt-0.5 h-2.5 w-2.5 flex-shrink-0 rounded-full bg-accent" aria-hidden="true" />
            <p className="text-sm leading-relaxed text-accent/90">
              Le vendeur vous contactera par WhatsApp ou téléphone pour confirmer et organiser la
              livraison.
            </p>
          </div>
        </section>
      </main>
    </div>
  )
}
