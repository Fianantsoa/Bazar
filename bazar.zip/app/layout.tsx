import type { Metadata } from 'next'
import { Plus_Jakarta_Sans, Playfair_Display } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const plusJakarta = Plus_Jakarta_Sans({ 
  subsets: ["latin"],
  variable: '--font-sans',
})
const playfair = Playfair_Display({ 
  subsets: ["latin"],
  variable: '--font-serif',
})

export const metadata: Metadata = {
  title: 'Bazar.app - Ta boutique en ligne en 5 minutes',
  description: 'Cree ta boutique en ligne, partage tes produits sur Facebook et TikTok, recois tes commandes de facon organisee. Gratuit pour commencer.',
  generator: 'v0.app',
  openGraph: {
    title: 'Bazar.app - Ta boutique en 5 minutes',
    description: 'Vends sur Facebook et TikTok avec ta propre boutique en ligne professionnelle.',
    type: 'website',
    locale: 'fr_MG',
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr" className={`${plusJakarta.variable} ${playfair.variable} bg-background`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
