import { Metadata } from 'next'
import {
  HeroConfirmation,
  OrderCard,
  DeliveryCard,
  TrackingCard,
  SellerCard,
  ActionButtons,
} from '@/components/confirmation'

export const metadata: Metadata = {
  title: 'Commande confirmee - Bazar',
  description: 'Votre commande a ete recue avec succes',
}

// Donnees de demo - en production, ces donnees viendraient de l'API
const demoOrder = {
  orderNumber: '#BZ-4821',
  item: {
    name: 'Robe Fleurie d\'Ete',
    variant: 'Taille M - Coloris Bleu',
    quantity: 1,
    price: 45000,
    emoji: '👗',
  },
  total: 45000,
  delivery: {
    clientName: 'Miora Rasoamanarivo',
    phone: '+261 34 12 345 67',
    address: 'Lot II C 34, Antananarivo 101',
  },
  seller: {
    name: 'Fashion Tana',
    initial: 'F',
    badge: 'Vendeur verifie - Repond vite',
    whatsappNumber: '261341234567',
    phoneNumber: '+261341234567',
  },
  status: 'pending' as const,
  shopSlug: 'fashion-tana',
}

export default function ConfirmationPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[420px] mx-auto">
        {/* Top bar */}
        <header className="bg-secondary px-5 py-3.5 flex items-center justify-between">
          <span className="font-serif text-xl sm:text-[22px] text-secondary-foreground tracking-tight">
            bazar<span className="text-primary">.</span>app
          </span>
          <span className="bg-primary/15 text-primary text-[11px] font-medium px-2.5 py-1 rounded-full border border-primary/30">
            Nouvelle commande
          </span>
        </header>

        {/* Hero section */}
        <HeroConfirmation orderNumber={demoOrder.orderNumber} />

        {/* Body content */}
        <main className="px-4 py-5 space-y-3">
          <OrderCard item={demoOrder.item} total={demoOrder.total} />
          <DeliveryCard delivery={demoOrder.delivery} />
          <TrackingCard currentStatus={demoOrder.status} />
          <SellerCard seller={demoOrder.seller} />
          <ActionButtons shopSlug={demoOrder.shopSlug} />
        </main>
      </div>
    </div>
  )
}
