import { Topbar, Hero, HowItWorks, Features, Testimonials, Pricing, CtaSection, Footer } from '@/components/landing'

export default function LandingPage() {
  return (
    <>
      <Topbar />
      <main>
        <Hero />
        <HowItWorks />
        <Features />
        <Testimonials />
        <Pricing />
        <CtaSection />
      </main>
      <Footer />
    </>
  )
}
