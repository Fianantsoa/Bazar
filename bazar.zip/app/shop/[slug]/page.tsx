import { ShopStorefront } from '@/components/shop'
import { DEMO_SHOP } from '@/lib/shop-data'
import type { Metadata } from 'next'

// En production, ces donnees viendraient d'une API/base de donnees
export async function generateMetadata(): Promise<Metadata> {
  return {
    title: `${DEMO_SHOP.name} — bazar.app`,
    description: DEMO_SHOP.description,
    openGraph: {
      title: DEMO_SHOP.name,
      description: DEMO_SHOP.description,
    }
  }
}

export default function ShopPage() {
  // En production: fetch shop data by slug from params
  return <ShopStorefront shop={DEMO_SHOP} />
}
