'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { i18n, type Language, type TranslationKey } from '@/lib/i18n'

interface LanguageStore {
  lang: Language
  setLang: (lang: Language) => void
  t: (key: TranslationKey) => string
}

export const useLanguage = create<LanguageStore>()(
  persist(
    (set, get) => ({
      lang: 'fr',
      setLang: (lang) => set({ lang }),
      t: (key) => i18n[get().lang][key] || key,
    }),
    {
      name: 'bazar-lang',
    }
  )
)
