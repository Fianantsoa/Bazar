'use client'

import { useState, useMemo } from 'react'
import Link from 'next/link'
import { Search, MapPin, Clock, Phone, X, Check, Minus, Plus, ChevronRight } from 'lucide-react'
import { type Shop, type Product, formatPrice } from '@/lib/shop-data'

interface ShopStorefrontProps {
  shop: Shop
}

export function ShopStorefront({ shop }: ShopStorefrontProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [activeCategory, setActiveCategory] = useState('all')
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [orderSuccess, setOrderSuccess] = useState(false)

  const filteredProducts = useMemo(() => {
    return shop.products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesCategory = activeCategory === 'all' || product.category === activeCategory
      return matchesSearch && matchesCategory
    })
  }, [shop.products, searchQuery, activeCategory])

  const openOrderModal = (product: Product) => {
    if (product.status === 'rupture') return
    setSelectedProduct(product)
    setOrderSuccess(false)
  }

  const closeModal = () => {
    setSelectedProduct(null)
    setOrderSuccess(false)
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Topbar */}
      <nav className="sticky top-0 z-50 bg-[#1E2D3D] px-4 py-2.5 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#F5A623] rounded-lg flex items-center justify-center font-serif font-bold text-[#1E2D3D]">
            B
          </div>
          <span className="font-serif font-bold text-white text-lg">bazar<span className="text-[#8A9BB0] text-xs tracking-widest">.app</span></span>
        </Link>
        <Link 
          href="/auth" 
          className="bg-[#F5A623] text-[#1E2D3D] text-xs font-medium px-3 py-1.5 rounded-lg hover:bg-[#e69a1f] transition-colors"
        >
          Creer ma boutique
        </Link>
      </nav>

      {/* Shop Banner */}
      <header className="bg-[#1E2D3D] px-6 py-10 text-center relative overflow-hidden">
        {/* Decorative circles */}
        <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-[#F5A623]/10" />
        <div className="absolute -bottom-12 -left-12 w-32 h-32 rounded-full bg-[#F5A623]/5" />
        
        {/* Avatar */}
        <div className="relative z-10 w-20 h-20 mx-auto mb-4 bg-[#F5A623] rounded-2xl flex items-center justify-center font-serif text-4xl font-bold text-[#1E2D3D]">
          {shop.avatar}
        </div>
        
        {/* Shop Name */}
        <h1 className="relative z-10 font-serif text-2xl sm:text-3xl text-white mb-2">{shop.name}</h1>
        
        {/* Description */}
        <p className="relative z-10 text-sm text-[#8A9BB0] max-w-sm mx-auto leading-relaxed mb-4">
          {shop.description}
        </p>
        
        {/* Meta badges */}
        <div className="relative z-10 flex flex-wrap items-center justify-center gap-3 text-xs">
          {shop.deliveryAvailable && (
            <span className="inline-flex items-center gap-1.5 bg-[#F5A623]/15 border border-[#F5A623]/30 text-[#F5A623] px-3 py-1.5 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-[#F5A623] animate-pulse" />
              Livraison disponible
            </span>
          )}
          <span className="inline-flex items-center gap-1.5 text-[#8A9BB0]">
            <Clock className="w-3.5 h-3.5" />
            Repond en {shop.responseTime}
          </span>
          <span className="inline-flex items-center gap-1.5 text-[#8A9BB0]">
            <MapPin className="w-3.5 h-3.5" />
            {shop.location}
          </span>
        </div>
        
        {/* WhatsApp button */}
        <a 
          href={`https://wa.me/${shop.whatsapp}`}
          target="_blank"
          rel="noopener noreferrer"
          className="relative z-10 inline-flex items-center gap-2 mt-5 bg-[#25D366] text-white px-5 py-2.5 rounded-full text-sm font-medium hover:bg-[#22c55e] transition-colors"
        >
          <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
            <path d="M12 2C6.477 2 2 6.477 2 12c0 1.89.525 3.66 1.438 5.168L2 22l4.832-1.438A9.96 9.96 0 0012 22c5.523 0 10-4.477 10-10S17.523 2 12 2z"/>
          </svg>
          Contacter sur WhatsApp
        </a>
      </header>

      {/* Search & Filters - Sticky */}
      <div className="sticky top-[52px] z-40 bg-white border-b border-[#1E2D3D]/10 px-4 py-3">
        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B7A8D]" />
          <input
            type="text"
            placeholder="Rechercher un produit..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-[#F5F5F0] border border-[#1E2D3D]/15 rounded-xl text-sm focus:outline-none focus:border-[#1E2D3D] transition-colors"
          />
        </div>
        
        {/* Categories */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide -mx-4 px-4">
          <button
            onClick={() => setActiveCategory('all')}
            className={`shrink-0 px-4 py-1.5 rounded-full text-xs font-medium border transition-colors ${
              activeCategory === 'all'
                ? 'bg-[#1E2D3D] border-[#1E2D3D] text-white'
                : 'bg-transparent border-[#1E2D3D]/15 text-[#6B7A8D] hover:border-[#1E2D3D] hover:text-[#1E2D3D]'
            }`}
          >
            Tout voir
          </button>
          {shop.categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`shrink-0 px-4 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                activeCategory === cat
                  ? 'bg-[#1E2D3D] border-[#1E2D3D] text-white'
                  : 'bg-transparent border-[#1E2D3D]/15 text-[#6B7A8D] hover:border-[#1E2D3D] hover:text-[#1E2D3D]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <main className="px-4 py-5 max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-serif text-xl text-[#1E2D3D]">Nos produits</h2>
          <span className="text-sm text-[#6B7A8D]">{filteredProducts.length} article{filteredProducts.length > 1 ? 's' : ''}</span>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="text-center py-12 text-[#6B7A8D]">
            <Search className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">Aucun produit trouve</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {filteredProducts.map((product, index) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onClick={() => openOrderModal(product)}
                style={{ animationDelay: `${index * 50}ms` }}
              />
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-[#1E2D3D] px-6 py-6 text-center mt-10">
        <p className="text-xs text-[#8A9BB0]">
          Boutique propulsee par <Link href="/" className="text-[#F5A623] hover:underline">bazar.app</Link>
        </p>
        <p className="text-xs text-[#8A9BB0] mt-1">
          2025 {shop.name} - {shop.location}, Madagascar
        </p>
      </footer>

      {/* Order Modal */}
      {selectedProduct && (
        <OrderModal 
          product={selectedProduct} 
          shop={shop}
          onClose={closeModal}
          orderSuccess={orderSuccess}
          setOrderSuccess={setOrderSuccess}
        />
      )}
    </div>
  )
}

// Product Card Component
function ProductCard({ 
  product, 
  onClick,
  style 
}: { 
  product: Product
  onClick: () => void
  style?: React.CSSProperties
}) {
  const isOutOfStock = product.status === 'rupture'
  const hasPromo = product.oldPrice && product.oldPrice > product.price

  return (
    <div 
      onClick={onClick}
      style={style}
      className={`bg-white rounded-2xl overflow-hidden border border-[#1E2D3D]/5 transition-all duration-200 animate-fade-up ${
        isOutOfStock ? 'opacity-60' : 'cursor-pointer hover:shadow-lg hover:-translate-y-1'
      }`}
    >
      {/* Image placeholder */}
      <div className="relative aspect-square bg-gradient-to-br from-[#F5F5F0] to-[#E8E8E3] flex items-center justify-center">
        <span className="text-4xl opacity-30">
          {product.category === 'Robes' && '👗'}
          {product.category === 'Hauts' && '👚'}
          {product.category === 'Accessoires' && '👜'}
          {product.category === 'Chaussures' && '👡'}
          {product.category === 'Beaute' && '🧴'}
        </span>
        
        {/* Badges */}
        {isOutOfStock && (
          <span className="absolute top-2 left-2 bg-red-500 text-white text-[10px] font-medium px-2 py-0.5 rounded-md">
            Rupture
          </span>
        )}
        {hasPromo && !isOutOfStock && (
          <span className="absolute top-2 left-2 bg-[#F5A623] text-[#1E2D3D] text-[10px] font-medium px-2 py-0.5 rounded-md">
            Promo
          </span>
        )}
      </div>

      {/* Info */}
      <div className="p-3">
        <p className="text-xs text-[#6B7A8D] mb-1">{product.category}</p>
        <h3 className="text-sm font-medium text-[#1E2D3D] line-clamp-2 leading-tight mb-2">
          {product.name}
        </h3>
        <div className="flex items-baseline gap-2">
          <span className="font-serif text-base text-[#1E2D3D]">{formatPrice(product.price)}</span>
          {hasPromo && (
            <span className="text-xs text-[#6B7A8D] line-through">{formatPrice(product.oldPrice!)}</span>
          )}
        </div>
        
        <button
          disabled={isOutOfStock}
          className={`w-full mt-2 py-2 rounded-xl text-xs font-medium transition-colors ${
            isOutOfStock 
              ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
              : 'bg-[#1E2D3D] text-white hover:bg-[#162230] active:scale-[0.98]'
          }`}
        >
          {isOutOfStock ? 'Indisponible' : 'Commander'}
        </button>
      </div>
    </div>
  )
}

// Order Modal Component
function OrderModal({ 
  product, 
  shop,
  onClose,
  orderSuccess,
  setOrderSuccess
}: { 
  product: Product
  shop: Shop
  onClose: () => void
  orderSuccess: boolean
  setOrderSuccess: (v: boolean) => void
}) {
  const [quantity, setQuantity] = useState(1)
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    variant: 'Standard',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name || !formData.phone || !formData.address) return
    
    setIsSubmitting(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    setIsSubmitting(false)
    setOrderSuccess(true)
  }

  const total = product.price * quantity

  return (
    <div 
      className="fixed inset-0 z-[200] bg-black/50 flex items-end sm:items-center justify-center"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[90vh] overflow-y-auto animate-slide-up">
        {/* Handle bar (mobile) */}
        <div className="sm:hidden w-10 h-1 bg-[#1E2D3D]/15 rounded-full mx-auto mt-3" />
        
        {/* Close button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-[#F5F5F0] flex items-center justify-center text-[#6B7A8D] hover:bg-[#1E2D3D]/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="p-6 relative">
          {!orderSuccess ? (
            <>
              <h3 className="font-serif text-xl text-[#1E2D3D] mb-1">Commander ce produit</h3>
              <p className="text-sm text-[#6B7A8D] mb-4">Remplissez le formulaire, le vendeur vous contacte.</p>

              {/* Product info */}
              <div className="flex gap-3 items-center p-3 bg-[#F5F5F0] rounded-xl mb-5">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-white to-[#E8E8E3] flex items-center justify-center text-2xl shrink-0">
                  {product.category === 'Robes' && '👗'}
                  {product.category === 'Hauts' && '👚'}
                  {product.category === 'Accessoires' && '👜'}
                  {product.category === 'Chaussures' && '👡'}
                  {product.category === 'Beaute' && '🧴'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#1E2D3D] truncate">{product.name}</p>
                  <p className="text-sm text-[#6B7A8D]">{formatPrice(product.price)}</p>
                </div>
              </div>

              {/* Quantity selector */}
              <div className="flex items-center justify-between p-3 bg-[#F5F5F0] rounded-xl mb-4">
                <span className="text-sm font-medium text-[#1E2D3D]">Quantite</span>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-8 h-8 rounded-lg bg-white border border-[#1E2D3D]/15 flex items-center justify-center text-[#1E2D3D] hover:border-[#1E2D3D] transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-8 text-center font-medium text-[#1E2D3D]">{quantity}</span>
                  <button
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-8 h-8 rounded-lg bg-white border border-[#1E2D3D]/15 flex items-center justify-center text-[#1E2D3D] hover:border-[#1E2D3D] transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-[#1E2D3D] mb-1.5">Nom complet *</label>
                    <input
                      type="text"
                      required
                      placeholder="Votre nom"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3 py-2.5 border border-[#1E2D3D]/20 rounded-xl text-sm focus:outline-none focus:border-[#1E2D3D] transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#1E2D3D] mb-1.5">Telephone *</label>
                    <input
                      type="tel"
                      required
                      placeholder="034 XX XXX XX"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-3 py-2.5 border border-[#1E2D3D]/20 rounded-xl text-sm focus:outline-none focus:border-[#1E2D3D] transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#1E2D3D] mb-1.5">Adresse de livraison *</label>
                  <input
                    type="text"
                    required
                    placeholder="Quartier, rue, ville"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#1E2D3D]/20 rounded-xl text-sm focus:outline-none focus:border-[#1E2D3D] transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#1E2D3D] mb-1.5">Variante</label>
                  <select
                    value={formData.variant}
                    onChange={(e) => setFormData({ ...formData, variant: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#1E2D3D]/20 rounded-xl text-sm focus:outline-none focus:border-[#1E2D3D] transition-colors bg-white"
                  >
                    <option>Standard</option>
                    <option>S</option>
                    <option>M</option>
                    <option>L</option>
                    <option>XL</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#1E2D3D] mb-1.5">Message (optionnel)</label>
                  <textarea
                    placeholder="Precisions, couleur souhaitee..."
                    rows={2}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-3 py-2.5 border border-[#1E2D3D]/20 rounded-xl text-sm focus:outline-none focus:border-[#1E2D3D] transition-colors resize-none"
                  />
                </div>

                {/* Total */}
                <div className="flex items-center justify-between py-3 border-t border-[#1E2D3D]/10">
                  <span className="text-sm text-[#6B7A8D]">Total</span>
                  <span className="font-serif text-xl text-[#1E2D3D]">{formatPrice(total)}</span>
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-[#1E2D3D] text-white rounded-xl font-medium text-sm hover:bg-[#162230] transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      Commander maintenant
                      <ChevronRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </>
          ) : (
            <div className="text-center py-6">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-serif text-2xl text-[#1E2D3D] mb-2">Commande envoyee !</h3>
              <p className="text-sm text-[#6B7A8D] leading-relaxed max-w-xs mx-auto">
                {shop.name.split(' ')[0]} vous contactera dans {shop.responseTime} pour confirmer votre commande et organiser la livraison.
              </p>
              <button
                onClick={onClose}
                className="mt-6 w-full py-3 bg-[#1E2D3D] text-white rounded-xl font-medium text-sm hover:bg-[#162230] transition-colors"
              >
                Fermer
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
