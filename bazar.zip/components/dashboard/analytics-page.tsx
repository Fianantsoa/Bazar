'use client'

import { Eye, ShoppingCart, PieChart, TrendingUp } from 'lucide-react'
import { trafficSources, topProducts } from '@/lib/dashboard-data'

export function AnalyticsPage() {
  return (
    <div className="space-y-5">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 lg:gap-4">
        <StatCard 
          icon={<Eye className="w-4 h-4" />}
          label="Vues totales"
          value="4 821"
          trend="+23% ce mois"
        />
        <StatCard 
          icon={<ShoppingCart className="w-4 h-4" />}
          label="Commandes"
          value="284"
          subtext="Ce mois"
        />
        <StatCard 
          icon={<PieChart className="w-4 h-4" />}
          label="Taux conversion"
          value="18%"
          trend="+3pts vs mois dernier"
        />
      </div>

      {/* Traffic and Top Products */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* Traffic Sources */}
        <div className="bg-white rounded-2xl p-4 lg:p-5 border border-stone-200">
          <h3 className="text-sm font-semibold text-[#1E2D3D] mb-4">Sources de trafic</h3>
          <div className="space-y-4">
            {trafficSources.map(source => (
              <div key={source.name}>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-[#1E2D3D]">{source.name}</span>
                  <span className="text-slate-500">{source.percentage}% — {source.clicks.toLocaleString()} clics</span>
                </div>
                <div className="h-2 bg-stone-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${source.percentage}%`, backgroundColor: source.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Products */}
        <div className="bg-white rounded-2xl p-4 lg:p-5 border border-stone-200">
          <h3 className="text-sm font-semibold text-[#1E2D3D] mb-4">Top produits cliqués</h3>
          <div className="space-y-3">
            {topProducts.map((product, index) => (
              <div key={product.name} className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-lg bg-stone-100 text-xs text-slate-500 flex items-center justify-center font-medium">
                    {index + 1}
                  </span>
                  <span className="text-sm text-[#1E2D3D]">{product.name}</span>
                </div>
                <span className="text-sm font-semibold text-[#1E2D3D]">{product.views} vues</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function StatCard({ icon, label, value, trend, subtext }: { 
  icon: React.ReactNode
  label: string
  value: string
  trend?: string
  subtext?: string
}) {
  return (
    <div className="bg-white rounded-2xl p-4 border border-stone-200">
      <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
        <span className="text-[#F5A623]">{icon}</span>
        <span>{label}</span>
      </div>
      <div className="text-2xl font-bold text-[#1E2D3D]">{value}</div>
      {trend && (
        <div className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
          <TrendingUp className="w-3 h-3" />
          {trend}
        </div>
      )}
      {subtext && (
        <div className="text-xs text-slate-500 mt-1">{subtext}</div>
      )}
    </div>
  )
}
