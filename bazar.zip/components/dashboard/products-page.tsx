'use client'

import { useState } from 'react'
import { Search, Plus, Edit, QrCode, Trash2, X, Copy, Check, ExternalLink } from 'lucide-react'
import Link from 'next/link'
import { products, Product, ProductStatus, getProductStatusColor } from '@/lib/dashboard-data'

const statusOptions: ProductStatus[] = ['Disponible', 'Rupture', 'Archivé']
const categoryOptions = ['Robes', 'Sacs', 'Chaussures', 'Bijoux', 'Ensembles']
const filterOptions = ['all', 'Disponible', 'Rupture'] as const

interface ProductsPageProps {
  onAddProduct?: () => void
}

export function ProductsPage({ onAddProduct }: ProductsPageProps) {
  const [filter, setFilter] = useState<typeof filterOptions[number]>('all')
  const [search, setSearch] = useState('')
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [isAddingProduct, setIsAddingProduct] = useState(false)
  const [copiedLink, setCopiedLink] = useState<string | null>(null)

  const filteredProducts = products
    .filter(p => filter === 'all' || p.status === filter)
    .filter(p => p.name.toLowerCase().includes(search.toLowerCase()))

  const copyLink = (link: string) => {
    navigator.clipboard.writeText(link)
    setCopiedLink(link)
    setTimeout(() => setCopiedLink(null), 2000)
  }

  const getStockColor = (stock: number) => {
    if (stock === 0) return 'bg-red-500'
    if (stock <= 2) return 'bg-amber-500'
    return 'bg-emerald-500'
  }

  return (
    <>
      <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-stone-200">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Rechercher un produit..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full sm:w-48 pl-9 pr-4 py-2 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623]"
                />
              </div>
              {/* Filters */}
              <div className="flex gap-2 overflow-x-auto pb-1 -mb-1 sm:pb-0 sm:mb-0">
                {filterOptions.map(option => (
                  <button
                    key={option}
                    onClick={() => setFilter(option)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-full border whitespace-nowrap transition-colors ${
                      filter === option
                        ? 'bg-[#1E2D3D] text-white border-[#1E2D3D]'
                        : 'bg-white text-slate-600 border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    {option === 'all' ? 'Tous' : option === 'Disponible' ? 'Disponibles' : option}
                  </button>
                ))}
              </div>
            </div>
            <Link 
              href="/dashboard/products/new"
              className="flex items-center justify-center gap-2 px-4 py-2 bg-[#F5A623] text-[#1E2D3D] text-sm font-bold rounded-xl hover:bg-[#e69a1f] transition-colors"
            >
              <Plus className="w-4 h-4" />
              Nouveau produit
            </Link>
          </div>
        </div>

        {/* Mobile Card View */}
        <div className="lg:hidden divide-y divide-stone-100">
          {filteredProducts.map(product => {
            const statusColors = getProductStatusColor(product.status)
            return (
              <div key={product.name} className="p-4">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#F5A623] to-[#f5c35a] flex items-center justify-center text-lg text-[#1E2D3D] font-bold flex-shrink-0">
                    {product.name[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-[#1E2D3D] truncate">{product.name}</div>
                    <div className="text-xs text-slate-500">{product.category}</div>
                    <div className="text-sm font-semibold text-[#1E2D3D] mt-0.5">{product.price}</div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full flex-shrink-0 ${statusColors.bg} ${statusColors.text}`}>
                    {product.status}
                  </span>
                </div>
                
                {/* Stock bar */}
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs text-slate-500">Stock</span>
                  <div className="flex-1 h-1.5 bg-stone-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${getStockColor(product.stock)}`}
                      style={{ width: `${Math.min(100, product.stock * 10)}%` }}
                    />
                  </div>
                  <span className="text-xs text-slate-600 w-5 text-right">{product.stock}</span>
                </div>

                {/* Link */}
                <div className="flex items-center gap-2 p-2 bg-stone-50 rounded-xl mb-3">
                  <span className="flex-1 text-xs text-slate-500 font-mono truncate">{product.link}</span>
                  <button 
                    onClick={() => copyLink(product.link)}
                    className="px-2 py-1 text-[10px] font-bold text-[#1E2D3D] bg-[#F5A623] rounded-lg hover:bg-[#e69a1f]"
                  >
                    {copiedLink === product.link ? <Check className="w-3 h-3" /> : 'Copier'}
                  </button>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button 
                    onClick={() => setEditingProduct(product)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs text-slate-600 border border-stone-200 rounded-xl hover:bg-stone-50"
                  >
                    <Edit className="w-3.5 h-3.5" />
                    Modifier
                  </button>
                  <button className="flex items-center justify-center w-10 py-2 text-slate-600 border border-stone-200 rounded-xl hover:bg-stone-50">
                    <QrCode className="w-3.5 h-3.5" />
                  </button>
                  <button className="flex items-center justify-center w-10 py-2 text-red-500 border border-red-200 rounded-xl hover:bg-red-50">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )
          })}
        </div>

        {/* Desktop Table View */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-stone-50 text-left">
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Produit</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Catégorie</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Prix</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Stock</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Statut</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Lien</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredProducts.map(product => {
                const statusColors = getProductStatusColor(product.status)
                return (
                  <tr key={product.name} className="hover:bg-stone-50/50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#F5A623] to-[#f5c35a] flex items-center justify-center text-sm text-[#1E2D3D] font-bold flex-shrink-0">
                          {product.name[0]}
                        </div>
                        <span className="text-sm font-medium text-[#1E2D3D]">{product.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-500">{product.category}</td>
                    <td className="px-4 py-3 text-sm font-semibold text-[#1E2D3D]">{product.price}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-1.5 bg-stone-100 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${getStockColor(product.stock)}`}
                            style={{ width: `${Math.min(100, product.stock * 10)}%` }}
                          />
                        </div>
                        <span className="text-xs text-slate-500">{product.stock}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors.bg} ${statusColors.text}`}>
                        {product.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2 px-2 py-1 bg-stone-50 rounded-lg max-w-[180px]">
                        <span className="flex-1 text-[10px] text-slate-500 font-mono truncate">{product.link}</span>
                        <button 
                          onClick={() => copyLink(product.link)}
                          className="p-1 text-[#1E2D3D] bg-[#F5A623] rounded text-[9px] font-bold hover:bg-[#e69a1f]"
                        >
                          {copiedLink === product.link ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1.5">
                        <button 
                          onClick={() => setEditingProduct(product)}
                          className="p-1.5 text-slate-500 hover:text-[#1E2D3D] hover:bg-stone-100 rounded-lg transition-colors"
                          title="Modifier"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                          className="p-1.5 text-slate-500 hover:text-[#1E2D3D] hover:bg-stone-100 rounded-lg transition-colors"
                          title="QR Code"
                        >
                          <QrCode className="w-4 h-4" />
                        </button>
                        <button 
                          className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Supprimer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Product Modal */}
      {(editingProduct || isAddingProduct) && (
        <ProductModal 
          product={editingProduct} 
          onClose={() => {
            setEditingProduct(null)
            setIsAddingProduct(false)
          }} 
        />
      )}
    </>
  )
}

function ProductModal({ product, onClose }: { product: Product | null; onClose: () => void }) {
  const isEditing = !!product
  
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full sm:w-[440px] sm:rounded-2xl rounded-t-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b border-stone-200">
          <h2 className="text-base font-semibold text-[#1E2D3D]">
            {isEditing ? `Modifier : ${product.name}` : 'Nouveau produit'}
          </h2>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4 space-y-4">
          <div>
            <label className="block text-xs text-slate-500 mb-1.5">Nom du produit</label>
            <input 
              type="text" 
              defaultValue={product?.name || ''}
              placeholder="Ex : Robe Fleurie Taille M"
              className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623]"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-500 mb-1.5">Prix (Ar)</label>
              <input 
                type="number" 
                defaultValue={product ? parseInt(product.price.replace(/\s/g, '')) : ''}
                placeholder="25000"
                className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623]"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1.5">Stock</label>
              <input 
                type="number" 
                defaultValue={product?.stock || ''}
                placeholder="10"
                className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623]"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-xs text-slate-500 mb-1.5">Catégorie</label>
            <select 
              defaultValue={product?.category || categoryOptions[0]}
              className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623] bg-white"
            >
              {categoryOptions.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-xs text-slate-500 mb-1.5">Description</label>
            <textarea 
              rows={2}
              placeholder="Description courte..."
              className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623] resize-none"
            />
          </div>
          
          <div>
            <label className="block text-xs text-slate-500 mb-1.5">Statut</label>
            <select 
              defaultValue={product?.status || statusOptions[0]}
              className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623] bg-white"
            >
              {statusOptions.map(status => (
                <option key={status} value={status}>{status}</option>
              ))}
            </select>
          </div>
        </div>
        
        <div className="p-4 border-t border-stone-200 flex gap-3">
          <button 
            onClick={onClose}
            className="flex-1 py-2.5 text-sm text-slate-600 border border-stone-200 rounded-xl hover:bg-stone-50"
          >
            Annuler
          </button>
          <button 
            onClick={onClose}
            className="flex-1 py-2.5 text-sm font-bold text-[#1E2D3D] bg-[#F5A623] rounded-xl hover:bg-[#e69a1f]"
          >
            Enregistrer le produit
          </button>
        </div>
      </div>
    </div>
  )
}
