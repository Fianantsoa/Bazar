'use client'

import { useState } from 'react'
import { Eye, Phone, Download, X } from 'lucide-react'
import { orders, Order, OrderStatus, getStatusColor, sendWhatsAppMessage } from '@/lib/dashboard-data'

const statusOptions: OrderStatus[] = ['Nouvelle', 'Confirmée', 'En livraison', 'Livrée', 'Annulée']
const filterOptions = ['all', ...statusOptions] as const

export function OrdersPage() {
  const [filter, setFilter] = useState<typeof filterOptions[number]>('all')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)

  const filteredOrders = filter === 'all' 
    ? orders 
    : orders.filter(o => o.status === filter)

  return (
    <>
      <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
        {/* Header with filters */}
        <div className="p-4 border-b border-stone-200">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            {/* Filters - scrollable on mobile */}
            <div className="flex gap-2 overflow-x-auto pb-1 -mb-1 sm:pb-0 sm:mb-0">
              {filterOptions.map(option => (
                <button
                  key={option}
                  onClick={() => setFilter(option)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-full border whitespace-nowrap transition-colors ${
                    filter === option
                      ? 'bg-[#1E2D3D] text-white border-[#1E2D3D]'
                      : 'bg-white text-slate-600 border-stone-200 hover:bg-stone-50'
                  }`}
                >
                  {option === 'all' ? 'Toutes' : option}
                </button>
              ))}
            </div>
            <button className="flex items-center gap-2 px-3 py-1.5 text-xs text-slate-600 border border-stone-200 rounded-xl hover:bg-stone-50 transition-colors self-start sm:self-auto">
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
          </div>
        </div>

        {/* Mobile Card View */}
        <div className="lg:hidden divide-y divide-stone-100">
          {filteredOrders.map(order => {
            const statusColors = getStatusColor(order.status)
            return (
              <div key={order.id} className="p-4">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <div className="font-medium text-[#1E2D3D] truncate">{order.name}</div>
                    <div className="text-xs text-slate-500">{order.product}</div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full flex-shrink-0 ${statusColors.bg} ${statusColors.text}`}>
                    {order.status}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="font-semibold text-[#1E2D3D]">{order.amount}</span>
                  <span className="text-xs text-slate-400">{order.date}</span>
                </div>
                <div className="flex gap-2 mt-3">
                  <button 
                    onClick={() => setSelectedOrder(order)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs text-slate-600 border border-stone-200 rounded-xl hover:bg-stone-50"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    Détail
                  </button>
                  <button 
                    onClick={() => sendWhatsAppMessage(order.name, order.product, order.amount)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs text-white bg-[#25D366] rounded-xl hover:bg-[#20bd5a]"
                  >
                    <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                    WhatsApp
                  </button>
                  <a 
                    href={`tel:${order.phone}`}
                    className="flex items-center justify-center w-10 py-2 text-slate-600 border border-stone-200 rounded-xl hover:bg-stone-50"
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            )
          })}
        </div>

        {/* Desktop Table View */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-stone-50 text-left">
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Client</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Produit</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Téléphone</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Montant</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Statut</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Date</th>
                <th className="px-4 py-3 text-xs font-medium text-slate-500">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredOrders.map(order => {
                const statusColors = getStatusColor(order.status)
                return (
                  <tr key={order.id} className="hover:bg-stone-50/50">
                    <td className="px-4 py-3 text-sm font-medium text-[#1E2D3D]">{order.name}</td>
                    <td className="px-4 py-3 text-sm text-slate-600">{order.product}</td>
                    <td className="px-4 py-3 text-sm">
                      <a href={`tel:${order.phone}`} className="text-[#1E2D3D] hover:underline">{order.phone}</a>
                    </td>
                    <td className="px-4 py-3 text-sm font-semibold text-[#1E2D3D]">{order.amount}</td>
                    <td className="px-4 py-3">
                      <select 
                        defaultValue={order.status}
                        className="text-xs px-2 py-1 rounded-lg border border-stone-200 bg-white focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30"
                      >
                        {statusOptions.map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500">{order.date}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1.5">
                        <button 
                          onClick={() => setSelectedOrder(order)}
                          className="p-1.5 text-slate-500 hover:text-[#1E2D3D] hover:bg-stone-100 rounded-lg transition-colors"
                          title="Voir détail"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => sendWhatsAppMessage(order.name, order.product, order.amount)}
                          className="p-1.5 text-[#25D366] hover:bg-[#25D366]/10 rounded-lg transition-colors"
                          title="WhatsApp"
                        >
                          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                          </svg>
                        </button>
                        <a 
                          href={`tel:${order.phone}`}
                          className="p-1.5 text-slate-500 hover:text-[#1E2D3D] hover:bg-stone-100 rounded-lg transition-colors"
                          title="Appeler"
                        >
                          <Phone className="w-4 h-4" />
                        </a>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <OrderDetailModal order={selectedOrder} onClose={() => setSelectedOrder(null)} />
      )}
    </>
  )
}

function OrderDetailModal({ order, onClose }: { order: Order; onClose: () => void }) {
  const statusColors = getStatusColor(order.status)
  
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full sm:w-[440px] sm:rounded-2xl rounded-t-2xl max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b border-stone-200">
          <h2 className="text-base font-semibold text-[#1E2D3D]">Détail commande</h2>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4 space-y-3">
          <DetailRow label="Commande" value={order.id} bold />
          <DetailRow label="Client" value={order.name} />
          <DetailRow label="Produit" value={order.product} />
          <DetailRow label="Téléphone" value={order.phone} link={`tel:${order.phone}`} />
          <DetailRow label="Montant" value={order.amount} highlight />
          <div className="flex justify-between items-center py-2">
            <span className="text-sm text-slate-500">Statut</span>
            <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors.bg} ${statusColors.text}`}>
              {order.status}
            </span>
          </div>
          <DetailRow label="Date" value={order.date} />
        </div>
        
        <div className="p-4 border-t border-stone-200 flex gap-3">
          <button 
            onClick={onClose}
            className="flex-1 py-2.5 text-sm text-slate-600 border border-stone-200 rounded-xl hover:bg-stone-50"
          >
            Fermer
          </button>
          <button 
            onClick={() => sendWhatsAppMessage(order.name, order.product, order.amount)}
            className="flex-1 py-2.5 text-sm font-bold text-[#1E2D3D] bg-[#F5A623] rounded-xl hover:bg-[#e69a1f]"
          >
            WhatsApp client
          </button>
        </div>
      </div>
    </div>
  )
}

function DetailRow({ label, value, bold, highlight, link }: { 
  label: string
  value: string
  bold?: boolean
  highlight?: boolean
  link?: string
}) {
  const ValueComponent = link ? 'a' : 'span'
  return (
    <div className="flex justify-between items-center py-2">
      <span className="text-sm text-slate-500">{label}</span>
      <ValueComponent 
        {...(link ? { href: link } : {})}
        className={`text-sm ${bold ? 'font-bold' : ''} ${highlight ? 'text-[#F5A623] font-bold' : 'text-[#1E2D3D]'} ${link ? 'hover:underline' : ''}`}
      >
        {value}
      </ValueComponent>
    </div>
  )
}
