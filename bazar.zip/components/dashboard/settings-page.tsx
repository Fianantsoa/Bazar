'use client'

import { useState } from 'react'
import { Copy, Check } from 'lucide-react'

export function SettingsPage() {
  const [copied, setCopied] = useState(false)
  const shopUrl = 'bazar.app/boutique/rova-fashions'

  const copyUrl = () => {
    navigator.clipboard.writeText(shopUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="max-w-xl">
      <div className="bg-white rounded-2xl p-4 lg:p-5 border border-stone-200">
        <h3 className="text-sm font-semibold text-[#1E2D3D] mb-4">Ma boutique</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-xs text-slate-500 mb-1.5">Nom de la boutique</label>
            <input 
              type="text" 
              defaultValue="Rova Fashions"
              className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623]"
            />
          </div>
          
          <div>
            <label className="block text-xs text-slate-500 mb-1.5">URL boutique</label>
            <div className="flex items-center gap-2 px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl">
              <span className="flex-1 text-sm text-slate-600 font-mono truncate">{shopUrl}</span>
              <button 
                onClick={copyUrl}
                className="flex items-center gap-1 px-2 py-1 text-xs font-bold text-[#1E2D3D] bg-[#F5A623] rounded-lg hover:bg-[#e69a1f] transition-colors"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copié!' : 'Copier'}
              </button>
            </div>
          </div>
          
          <div>
            <label className="block text-xs text-slate-500 mb-1.5">Numéro WhatsApp</label>
            <input 
              type="text" 
              defaultValue="+261 34 00 000 00"
              className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623]"
            />
          </div>
          
          <div>
            <label className="block text-xs text-slate-500 mb-1.5">Description</label>
            <textarea 
              rows={3}
              defaultValue="Boutique mode féminine à Antananarivo. Livraison partout à Madagascar."
              className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623] resize-none"
            />
          </div>
          
          <button className="w-full sm:w-auto px-6 py-2.5 text-sm font-bold text-[#1E2D3D] bg-[#F5A623] rounded-xl hover:bg-[#e69a1f] transition-colors">
            Enregistrer
          </button>
        </div>
      </div>
    </div>
  )
}
