'use client'

import { notifications } from '@/lib/dashboard-data'

export function NotificationsPage() {
  const getNotificationDot = (type: 'order' | 'stock' | 'delivery') => {
    const colors = {
      order: 'bg-[#F5A623]',
      stock: 'bg-red-500',
      delivery: 'bg-emerald-500',
    }
    return colors[type]
  }

  return (
    <div className="max-w-2xl">
      <div className="bg-white rounded-2xl p-4 lg:p-5 border border-stone-200">
        <h3 className="text-sm font-semibold text-[#1E2D3D] mb-4">Notifications récentes</h3>
        <div className="space-y-2">
          {notifications.map(notif => (
            <div 
              key={notif.id} 
              className="flex items-start gap-3 p-3 rounded-xl border border-stone-100 hover:bg-stone-50 transition-colors"
            >
              <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${getNotificationDot(notif.type)}`} />
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium text-[#1E2D3D]">{notif.title}</div>
                <div className="text-xs text-slate-500 mt-0.5">{notif.description}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
