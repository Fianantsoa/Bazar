"use client"

import { useState, useRef } from "react"
import { 
  Package, Camera, X, Plus, Check, 
  Copy, Trash2, Save, ChevronDown,
  AlertCircle, Bell, Link2, Tag
} from "lucide-react"

type ProductStatus = "available" | "outOfStock" | "archived"

interface ProductFormData {
  name: string
  description: string
  category: string
  subcategory: string
  price: string
  originalPrice: string
  stock: string
  alertThreshold: string
  status: ProductStatus
  photos: string[]
}

const CATEGORIES = [
  { value: "", label: "Choisir une categorie" },
  { value: "vetements-femme", label: "Vetements femme" },
  { value: "vetements-homme", label: "Vetements homme" },
  { value: "chaussures", label: "Chaussures" },
  { value: "accessoires", label: "Accessoires" },
  { value: "electronique", label: "Electronique" },
  { value: "maison-deco", label: "Maison & Deco" },
  { value: "beaute-soins", label: "Beaute & Soins" },
]

interface ProductFormProps {
  initialData?: Partial<ProductFormData>
  onSave?: (data: ProductFormData) => void
  onCancel?: () => void
  isEditing?: boolean
}

export function ProductForm({ initialData, onSave, onCancel, isEditing = false }: ProductFormProps) {
  const [formData, setFormData] = useState<ProductFormData>({
    name: initialData?.name || "",
    description: initialData?.description || "",
    category: initialData?.category || "",
    subcategory: initialData?.subcategory || "",
    price: initialData?.price || "",
    originalPrice: initialData?.originalPrice || "",
    stock: initialData?.stock || "",
    alertThreshold: initialData?.alertThreshold || "5",
    status: initialData?.status || "available",
    photos: initialData?.photos || [],
  })
  
  const [copied, setCopied] = useState(false)
  const [saving, setSaving] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const slugify = (str: string) => {
    return str
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9\s-]/g, "")
      .trim()
      .replace(/\s+/g, "-")
      .substring(0, 20)
  }

  const productLink = formData.name 
    ? `bazar.app/p/${slugify(formData.name)}` 
    : "bazar.app/p/..."

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(productLink)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // Fallback for older browsers
    }
  }

  const handlePhotoAdd = () => {
    if (formData.photos.length >= 5) return
    fileInputRef.current?.click()
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    
    // Simulate photo upload - in real app, upload to server
    const newPhotos = [...formData.photos]
    for (let i = 0; i < files.length && newPhotos.length < 5; i++) {
      newPhotos.push(`photo-${newPhotos.length + 1}`)
    }
    setFormData({ ...formData, photos: newPhotos })
    e.target.value = ""
  }

  const handlePhotoRemove = (index: number) => {
    const newPhotos = formData.photos.filter((_, i) => i !== index)
    setFormData({ ...formData, photos: newPhotos })
  }

  const handleSave = async (isDraft: boolean = false) => {
    if (!formData.name.trim()) return
    if (!isDraft && (!formData.price || parseFloat(formData.price) <= 0)) return
    
    setSaving(true)
    // Simulate save
    await new Promise(resolve => setTimeout(resolve, 500))
    setSaving(false)
    onSave?.(formData)
  }

  const statusOptions: { value: ProductStatus; label: string; color: string }[] = [
    { value: "available", label: "Disponible", color: "bg-green-100 text-green-700 border-green-300" },
    { value: "outOfStock", label: "En rupture", color: "bg-red-100 text-red-700 border-red-300" },
    { value: "archived", label: "Archive", color: "bg-gray-100 text-gray-600 border-gray-300" },
  ]

  return (
    <div className="min-h-screen bg-[#F5F5F0]">
      {/* Header fixe pour mobile */}
      <div className="sticky top-0 z-20 bg-[#1E2D3D] px-4 py-3 safe-area-top">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-[#F5A623] rounded-xl flex items-center justify-center flex-shrink-0">
            <span className="font-serif text-[#1E2D3D] text-lg font-bold">B</span>
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-white font-medium text-sm truncate">
              {isEditing ? "Modifier le produit" : "Nouveau produit"}
            </h1>
            <p className="text-[#8A9BB0] text-xs truncate">Ajout rapide</p>
          </div>
          <span className="text-[#F5A623] text-xs border border-[#F5A623]/40 rounded-full px-3 py-1">
            Brouillon
          </span>
        </div>
      </div>

      {/* Corps du formulaire - scroll */}
      <div className="px-4 py-4 pb-32 space-y-4">
        
        {/* Section Photos - En premier pour mobile */}
        <section className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="text-xs font-medium text-[#6B7A8D] uppercase tracking-wider mb-3 flex items-center gap-2">
            <Camera size={14} />
            Photos ({formData.photos.length}/5)
          </h2>
          
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handleFileChange}
          />
          
          {/* Zone de drop simplifiee */}
          {formData.photos.length === 0 ? (
            <button
              onClick={handlePhotoAdd}
              className="w-full border-2 border-dashed border-[#1E2D3D]/20 rounded-2xl p-8 
                         flex flex-col items-center gap-2 active:bg-[#1E2D3D]/5 transition-colors"
            >
              <div className="w-14 h-14 bg-[#1E2D3D]/5 rounded-full flex items-center justify-center">
                <Camera size={24} className="text-[#6B7A8D]" />
              </div>
              <p className="text-sm text-[#1E2D3D] font-medium">Ajouter des photos</p>
              <p className="text-xs text-[#6B7A8D]">JPG, PNG - Max 5 Mo</p>
            </button>
          ) : (
            <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1 snap-x">
              {formData.photos.map((photo, index) => (
                <div
                  key={index}
                  className="relative w-20 h-20 flex-shrink-0 bg-[#1E2D3D]/5 rounded-xl 
                             flex items-center justify-center snap-start"
                >
                  {index === 0 && (
                    <span className="absolute top-0 left-0 right-0 bg-[#F5A623] text-[#1E2D3D] 
                                     text-[10px] font-medium text-center py-0.5 rounded-t-xl">
                      Principal
                    </span>
                  )}
                  <span className="text-xs text-[#6B7A8D] mt-2">Photo {index + 1}</span>
                  <button
                    onClick={() => handlePhotoRemove(index)}
                    className="absolute -top-1 -right-1 w-6 h-6 bg-[#1E2D3D] text-white 
                               rounded-full flex items-center justify-center shadow-md"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
              {formData.photos.length < 5 && (
                <button
                  onClick={handlePhotoAdd}
                  className="w-20 h-20 flex-shrink-0 border-2 border-dashed border-[#1E2D3D]/20 
                             rounded-xl flex items-center justify-center active:bg-[#1E2D3D]/5 snap-start"
                >
                  <Plus size={24} className="text-[#6B7A8D]" />
                </button>
              )}
            </div>
          )}
        </section>

        {/* Informations essentielles */}
        <section className="bg-white rounded-2xl p-4 shadow-sm space-y-4">
          <h2 className="text-xs font-medium text-[#6B7A8D] uppercase tracking-wider flex items-center gap-2">
            <Package size={14} />
            Informations
          </h2>

          {/* Nom du produit */}
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-[#1E2D3D] flex items-center gap-1">
              Nom du produit <span className="text-[#F5A623]">*</span>
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Ex: Robe Wax Ankara bleue"
              maxLength={80}
              className="w-full px-4 py-3 border border-[#1E2D3D]/10 rounded-xl text-base
                         focus:outline-none focus:border-[#1E2D3D] focus:ring-2 focus:ring-[#1E2D3D]/10
                         placeholder:text-[#6B7A8D]/60"
            />
            <div className="flex justify-between">
              <span className="text-xs text-[#6B7A8D]">Soyez precis</span>
              <span className={`text-xs ${formData.name.length > 70 ? "text-red-500" : "text-[#6B7A8D]"}`}>
                {formData.name.length}/80
              </span>
            </div>
          </div>

          {/* Description - collapse sur mobile */}
          <details className="group">
            <summary className="text-sm font-medium text-[#1E2D3D] cursor-pointer flex items-center justify-between">
              <span>Description</span>
              <ChevronDown size={16} className="text-[#6B7A8D] group-open:rotate-180 transition-transform" />
            </summary>
            <div className="mt-2">
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Decrivez votre produit..."
                maxLength={600}
                rows={3}
                className="w-full px-4 py-3 border border-[#1E2D3D]/10 rounded-xl text-base resize-none
                           focus:outline-none focus:border-[#1E2D3D] focus:ring-2 focus:ring-[#1E2D3D]/10
                           placeholder:text-[#6B7A8D]/60"
              />
              <p className="text-xs text-[#6B7A8D] text-right mt-1">{formData.description.length}/600</p>
            </div>
          </details>

          {/* Categorie */}
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-[#1E2D3D] flex items-center gap-1">
              Categorie <span className="text-[#F5A623]">*</span>
            </label>
            <div className="relative">
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-4 py-3 border border-[#1E2D3D]/10 rounded-xl text-base
                           appearance-none bg-white
                           focus:outline-none focus:border-[#1E2D3D] focus:ring-2 focus:ring-[#1E2D3D]/10"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat.value} value={cat.value}>{cat.label}</option>
                ))}
              </select>
              <ChevronDown size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6B7A8D] pointer-events-none" />
            </div>
          </div>
        </section>

        {/* Prix & Stock - Section critique */}
        <section className="bg-white rounded-2xl p-4 shadow-sm space-y-4">
          <h2 className="text-xs font-medium text-[#6B7A8D] uppercase tracking-wider flex items-center gap-2">
            <Tag size={14} />
            Prix & Stock
          </h2>

          {/* Prix en grille 2 colonnes */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-[#1E2D3D] flex items-center gap-1">
                Prix <span className="text-[#F5A623]">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-[#6B7A8D] font-medium">Ar</span>
                <input
                  type="number"
                  inputMode="numeric"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  placeholder="0"
                  min="0"
                  className="w-full pl-10 pr-4 py-3 border border-[#1E2D3D]/10 rounded-xl text-base
                             focus:outline-none focus:border-[#1E2D3D] focus:ring-2 focus:ring-[#1E2D3D]/10"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-[#1E2D3D]">
                Prix barre
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-[#6B7A8D] font-medium">Ar</span>
                <input
                  type="number"
                  inputMode="numeric"
                  value={formData.originalPrice}
                  onChange={(e) => setFormData({ ...formData, originalPrice: e.target.value })}
                  placeholder="0"
                  min="0"
                  className="w-full pl-10 pr-4 py-3 border border-[#1E2D3D]/10 rounded-xl text-base
                             focus:outline-none focus:border-[#1E2D3D] focus:ring-2 focus:ring-[#1E2D3D]/10"
                />
              </div>
            </div>
          </div>

          {/* Stock */}
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-[#1E2D3D] flex items-center gap-1">
              Stock <span className="text-[#F5A623]">*</span>
            </label>
            <div className="flex gap-2 items-center">
              <input
                type="number"
                inputMode="numeric"
                value={formData.stock}
                onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                placeholder="0"
                min="0"
                className="flex-1 px-4 py-3 border border-[#1E2D3D]/10 rounded-xl text-base
                           focus:outline-none focus:border-[#1E2D3D] focus:ring-2 focus:ring-[#1E2D3D]/10"
              />
              <span className="text-sm text-[#6B7A8D]">unites</span>
            </div>
          </div>

          {/* Alerte stock */}
          <div className="flex items-center gap-3 p-3 bg-[#F5F5F0] rounded-xl">
            <Bell size={16} className="text-[#F5A623] flex-shrink-0" />
            <span className="text-sm text-[#1E2D3D] flex-1">Alerte si stock &lt;</span>
            <input
              type="number"
              inputMode="numeric"
              value={formData.alertThreshold}
              onChange={(e) => setFormData({ ...formData, alertThreshold: e.target.value })}
              min="1"
              className="w-16 px-2 py-1.5 border border-[#1E2D3D]/10 rounded-lg text-sm text-center
                         focus:outline-none focus:border-[#1E2D3D]"
            />
          </div>
        </section>

        {/* Statut */}
        <section className="bg-white rounded-2xl p-4 shadow-sm space-y-3">
          <h2 className="text-xs font-medium text-[#6B7A8D] uppercase tracking-wider">
            Statut
          </h2>
          <div className="flex gap-2 flex-wrap">
            {statusOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => setFormData({ ...formData, status: option.value })}
                className={`px-4 py-2.5 rounded-full text-sm font-medium border transition-all
                           ${formData.status === option.value 
                             ? option.color 
                             : "bg-white text-[#6B7A8D] border-[#1E2D3D]/10 active:bg-[#F5F5F0]"}`}
              >
                {formData.status === option.value && <Check size={14} className="inline mr-1.5 -mt-0.5" />}
                {option.label}
              </button>
            ))}
          </div>
        </section>

        {/* Lien partageable */}
        <section className="bg-white rounded-2xl p-4 shadow-sm space-y-3">
          <h2 className="text-xs font-medium text-[#6B7A8D] uppercase tracking-wider flex items-center gap-2">
            <Link2 size={14} />
            Lien partageable
          </h2>
          <div className="flex items-center gap-2 p-3 bg-[#F5F5F0] rounded-xl">
            <Link2 size={16} className="text-[#6B7A8D] flex-shrink-0" />
            <span className="text-sm text-[#6B7A8D] font-mono truncate flex-1">{productLink}</span>
            <button
              onClick={handleCopyLink}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all
                         ${copied 
                           ? "bg-green-100 text-green-700 border border-green-300" 
                           : "bg-white border border-[#1E2D3D]/10 text-[#6B7A8D] active:bg-[#1E2D3D]/5"}`}
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
              {copied ? "Copie!" : "Copier"}
            </button>
          </div>
          <p className="text-xs text-[#6B7A8D]">
            Partagez ce lien sur WhatsApp, Facebook ou TikTok
          </p>
        </section>
      </div>

      {/* Footer fixe - Actions principales */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#1E2D3D]/10 p-4 safe-area-bottom z-20">
        <div className="flex gap-3">
          {isEditing && (
            <button
              onClick={onCancel}
              className="p-3 rounded-xl border border-red-200 text-red-500 active:bg-red-50"
            >
              <Trash2 size={20} />
            </button>
          )}
          <button
            onClick={() => handleSave(true)}
            className="flex-1 py-3 px-4 rounded-xl border border-[#1E2D3D]/10 text-[#1E2D3D] 
                       font-medium text-sm flex items-center justify-center gap-2 active:bg-[#F5F5F0]"
          >
            <Save size={18} />
            Brouillon
          </button>
          <button
            onClick={() => handleSave(false)}
            disabled={saving || !formData.name.trim()}
            className="flex-1 py-3 px-4 rounded-xl bg-[#1E2D3D] text-white font-medium text-sm
                       flex items-center justify-center gap-2 active:bg-[#162230]
                       disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? (
              <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Check size={18} />
            )}
            Publier
          </button>
        </div>
      </div>
    </div>
  )
}
