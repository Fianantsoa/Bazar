'use client'

import { useDashboard } from '@/lib/dashboard-context'
import { 
  LayoutDashboard, 
  ShoppingBag, 
  Package, 
  BarChart3, 
  Bell, 
  Settings,
  X
} from 'lucide-react'

const navItems = [
  { id: 'overview' as const, label: 'Tableau de bord', icon: LayoutDashboard },
  { id: 'orders' as const, label: 'Commandes', icon: ShoppingBag, badge: 5 },
  { id: 'products' as const, label: 'Produits', icon: Package },
  { id: 'analytics' as const, label: 'Statistiques', icon: BarChart3 },
  { id: 'notifications' as const, label: 'Notifications', icon: Bell, badge: 3 },
  { id: 'settings' as const, label: 'Paramètres', icon: Settings },
]

export function Sidebar() {
  const { currentPage, setCurrentPage, sidebarOpen, setSidebarOpen } = useDashboard()

  return (
    <>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50
        w-64 bg-[#1E2D3D] flex flex-col
        transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Logo */}
        <div className="p-5 border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-[#F5A623] rounded-xl flex items-center justify-center">
                <span className="font-serif text-lg font-bold text-[#1E2D3D]">B</span>
              </div>
              <div>
                <div className="font-serif text-xl font-bold text-white">bazar</div>
                <div className="text-[11px] text-slate-400 tracking-widest">.app</div>
              </div>
            </div>
            <button 
              className="lg:hidden p-1 text-white/70 hover:text-white"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 overflow-y-auto">
          <div className="px-5 py-2 text-[10px] text-slate-400 tracking-widest uppercase">
            Principal
          </div>
          {navItems.slice(0, 3).map(item => (
            <NavItem key={item.id} item={item} />
          ))}
          
          <div className="px-5 py-2 mt-4 text-[10px] text-slate-400 tracking-widest uppercase">
            Boutique
          </div>
          {navItems.slice(3).map(item => (
            <NavItem key={item.id} item={item} />
          ))}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#F5A623] flex items-center justify-center text-[#1E2D3D] font-bold text-sm flex-shrink-0">
              RF
            </div>
            <div className="min-w-0">
              <div className="text-sm text-white font-medium truncate">Rova Fashions</div>
              <div className="text-xs text-slate-400">Plan Pro</div>
            </div>
          </div>
        </div>
      </aside>
    </>
  )
}

function NavItem({ item }: { item: typeof navItems[number] }) {
  const { currentPage, setCurrentPage, setSidebarOpen } = useDashboard()
  const isActive = currentPage === item.id
  const Icon = item.icon

  return (
    <button
      onClick={() => {
        setCurrentPage(item.id)
        setSidebarOpen(false)
      }}
      className={`
        w-full flex items-center gap-3 px-5 py-3 text-sm
        border-l-[3px] transition-all
        ${isActive 
          ? 'bg-[#F5A623]/10 text-[#F5A623] border-l-[#F5A623]' 
          : 'text-slate-400 border-l-transparent hover:bg-white/5 hover:text-white'
        }
      `}
    >
      <Icon className="w-[18px] h-[18px]" />
      <span className="flex-1 text-left">{item.label}</span>
      {item.badge && (
        <span className="px-2 py-0.5 bg-[#F5A623] text-[#1E2D3D] text-[10px] font-bold rounded-full">
          {item.badge}
        </span>
      )}
    </button>
  )
}
