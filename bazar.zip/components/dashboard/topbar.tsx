'use client'

import { useDashboard } from '@/lib/dashboard-context'
import { Menu, Search, Bell, Plus } from 'lucide-react'

const pageTitles = {
  overview: 'Tableau de bord',
  orders: 'Commandes',
  products: 'Produits',
  analytics: 'Statistiques',
  notifications: 'Notifications',
  settings: 'Paramètres',
}

interface TopbarProps {
  onAddProduct?: () => void
}

export function Topbar({ onAddProduct }: TopbarProps) {
  const { currentPage, setCurrentPage, setSidebarOpen } = useDashboard()

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-stone-200">
      <div className="flex items-center justify-between px-4 lg:px-6 h-14">
        {/* Left side */}
        <div className="flex items-center gap-3">
          <button 
            className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900 hover:bg-stone-100 rounded-xl"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>
          <h1 className="text-base font-semibold text-[#1E2D3D]">
            {pageTitles[currentPage]}
          </h1>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-2 lg:gap-3">
          {/* Search - hidden on mobile */}
          <div className="hidden sm:block relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher..."
              className="w-48 pl-9 pr-4 py-2 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F5A623]/30 focus:border-[#F5A623]"
            />
          </div>

          {/* Notifications */}
          <button 
            className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-stone-100 rounded-xl"
            onClick={() => setCurrentPage('notifications')}
          >
            <Bell className="w-5 h-5" />
            <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
              3
            </span>
          </button>

          {/* Add product button */}
          <button 
            className="flex items-center gap-2 px-3 py-2 bg-[#F5A623] text-[#1E2D3D] text-sm font-bold rounded-xl hover:bg-[#e69a1f] transition-colors"
            onClick={onAddProduct}
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Ajouter produit</span>
          </button>
        </div>
      </div>
    </header>
  )
}
