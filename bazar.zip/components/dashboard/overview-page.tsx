'use client'

import { ShoppingBag, Wallet, Package, Eye, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react'
import { orders, stockAlerts, chartData, getStatusColor, getInitials } from '@/lib/dashboard-data'
import { useDashboard } from '@/lib/dashboard-context'
import { BarChart, Bar, XAxis, ResponsiveContainer, Cell } from 'recharts'

export function OverviewPage() {
  const { setCurrentPage } = useDashboard()

  return (
    <div className="space-y-5">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <StatCard 
          icon={<ShoppingBag className="w-4 h-4" />}
          label="Commandes aujourd'hui"
          value="12"
          trend={{ value: '+4 vs hier', up: true }}
        />
        <StatCard 
          icon={<Wallet className="w-4 h-4" />}
          label="CA estimé ce mois"
          value="847 000"
          suffix="Ar"
          trend={{ value: '+12%', up: true }}
        />
        <StatCard 
          icon={<Package className="w-4 h-4" />}
          label="Produits actifs"
          value="38"
          trend={{ value: '3 en rupture', up: false, warning: true }}
        />
        <StatCard 
          icon={<Eye className="w-4 h-4" />}
          label="Vues liens (7j)"
          value="1 243"
          trend={{ value: 'Taux conv. 18%', up: true }}
        />
      </div>

      {/* Charts and Alerts Row */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* Chart Card */}
        <div className="bg-white rounded-2xl p-4 lg:p-5 border border-stone-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-[#1E2D3D]">Commandes — 7 derniers jours</h3>
            <span className="text-xs text-slate-500">Total : 64</span>
          </div>
          <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <XAxis 
                  dataKey="day" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#6B7A8D' }}
                />
                <Bar dataKey="orders" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={index >= 2 ? '#F5A623' : 'rgba(245,166,35,0.3)'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Stock Alerts Card */}
        <div className="bg-white rounded-2xl p-4 lg:p-5 border border-stone-200">
          <h3 className="text-sm font-semibold text-[#1E2D3D] mb-4">Alertes stock</h3>
          <div className="space-y-2">
            {stockAlerts.map((alert, i) => (
              <div 
                key={i} 
                className="flex items-center gap-3 p-3 rounded-xl bg-red-50 border border-red-100"
              >
                <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="text-sm text-[#1E2D3D] truncate">{alert.name}</div>
                  <div className="text-xs text-slate-500">
                    Stock : {alert.stock === 0 ? '0 — Rupture' : `${alert.stock} restant${alert.stock > 1 ? 's' : ''}`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-white rounded-2xl p-4 lg:p-5 border border-stone-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-[#1E2D3D]">Dernières commandes</h3>
          <button 
            className="text-xs text-slate-500 hover:text-[#1E2D3D] px-3 py-1.5 border border-stone-200 rounded-xl hover:bg-stone-50 transition-colors"
            onClick={() => setCurrentPage('orders')}
          >
            Voir tout
          </button>
        </div>
        <div className="space-y-2">
          {orders.slice(0, 4).map((order) => {
            const statusColors = getStatusColor(order.status)
            return (
              <div 
                key={order.id} 
                className="flex items-center gap-3 p-3 rounded-xl border border-stone-100 hover:bg-stone-50 transition-colors cursor-pointer"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold flex-shrink-0">
                  {getInitials(order.name)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-[#1E2D3D] truncate">{order.name}</div>
                  <div className="text-xs text-slate-500 truncate">{order.product}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-sm font-semibold text-[#1E2D3D]">{order.amount}</div>
                  <span className={`inline-block mt-0.5 text-[10px] px-2 py-0.5 rounded-full ${statusColors.bg} ${statusColors.text}`}>
                    {order.status}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

interface StatCardProps {
  icon: React.ReactNode
  label: string
  value: string
  suffix?: string
  trend: { value: string; up: boolean; warning?: boolean }
}

function StatCard({ icon, label, value, suffix, trend }: StatCardProps) {
  return (
    <div className="bg-white rounded-2xl p-4 border border-stone-200">
      <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
        <span className="text-[#F5A623]">{icon}</span>
        <span className="truncate">{label}</span>
      </div>
      <div className="text-xl lg:text-2xl font-bold text-[#1E2D3D]">
        {value}
        {suffix && <span className="text-sm font-normal text-slate-500 ml-1">{suffix}</span>}
      </div>
      <div className={`text-xs mt-1 flex items-center gap-1 ${
        trend.warning ? 'text-red-500' : trend.up ? 'text-emerald-600' : 'text-red-500'
      }`}>
        {trend.warning ? (
          <AlertTriangle className="w-3 h-3" />
        ) : trend.up ? (
          <TrendingUp className="w-3 h-3" />
        ) : (
          <TrendingDown className="w-3 h-3" />
        )}
        <span>{trend.value}</span>
      </div>
    </div>
  )
}
