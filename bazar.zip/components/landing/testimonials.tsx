'use client'

import { useLanguage } from '@/hooks/use-language'

export function Testimonials() {
  const { t } = useLanguage()

  const testimonials = [
    { quote: t('test1_quote'), name: t('test1_name'), role: t('test1_role'), initial: 'R' },
    { quote: t('test2_quote'), name: t('test2_name'), role: t('test2_role'), initial: 'S' },
    { quote: t('test3_quote'), name: t('test3_name'), role: t('test3_role'), initial: 'F' },
  ]

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-card" aria-labelledby="test-heading">
      <div className="container mx-auto px-4 lg:px-6">
        <h2 id="test-heading" className="font-serif text-2xl sm:text-3xl font-bold mb-2 text-foreground">
          {t('test_title')}
        </h2>
        <p className="text-muted-foreground mb-8 sm:mb-10 text-sm sm:text-base lg:text-lg">{t('test_sub')}</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {testimonials.map((test, i) => (
            <blockquote key={i} className="bg-muted rounded-xl sm:rounded-2xl p-5 sm:p-6 border-none">
              <p className="text-foreground italic text-sm sm:text-base leading-relaxed mb-4">{test.quote}</p>
              <footer className="flex items-center gap-3">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-primary flex items-center justify-center font-bold text-sm sm:text-base text-primary-foreground">
                  {test.initial}
                </div>
                <cite className="not-italic text-xs sm:text-sm text-muted-foreground">
                  <strong className="block text-foreground text-sm sm:text-base">{test.name}</strong>
                  {test.role}
                </cite>
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  )
}
