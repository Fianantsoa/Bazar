'use client'

import { useLanguage } from '@/hooks/use-language'
import { ArrowRight } from 'lucide-react'

export function HowItWorks() {
  const { t } = useLanguage()

  const steps = [
    { num: 1, title: t('step1_title'), desc: t('step1_desc') },
    { num: 2, title: t('step2_title'), desc: t('step2_desc') },
    { num: 3, title: t('step3_title'), desc: t('step3_desc') },
  ]

  return (
    <section id="how" className="py-12 sm:py-16 lg:py-20 bg-card" aria-labelledby="how-heading">
      <div className="container mx-auto px-4 lg:px-6">
        <h2 id="how-heading" className="font-serif text-2xl sm:text-3xl font-bold mb-2 text-foreground">
          {t('how_title')}
        </h2>
        <p className="text-muted-foreground mb-8 sm:mb-10 text-sm sm:text-base lg:text-lg">{t('how_sub')}</p>

        <div className="flex flex-col gap-3 sm:gap-4">
          {steps.map((step, i) => (
            <div key={step.num} className="flex flex-col lg:flex-row items-stretch lg:items-start w-full">
              <div className="flex-1 bg-muted rounded-xl sm:rounded-2xl p-5 sm:p-7 relative">
                <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-lg sm:rounded-xl bg-primary flex items-center justify-center font-serif text-lg sm:text-xl font-bold text-primary-foreground mb-3 sm:mb-4">
                  {step.num}
                </div>
                <h3 className="font-serif text-base sm:text-lg font-bold text-foreground mb-1.5 sm:mb-2">{step.title}</h3>
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
              </div>
              {i < steps.length - 1 && (
                <div className="hidden lg:flex items-center justify-center w-10 h-full self-center text-primary text-xl pt-10">
                  <ArrowRight className="w-5 h-5" />
                </div>
              )}
              {i < steps.length - 1 && (
                <div className="lg:hidden flex justify-center w-full py-2 text-primary">
                  <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 rotate-90" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
