'use client'

import { useLanguage } from '@/hooks/use-language'
import { Link2, Package, QrCode, FileText, MessageCircle, BarChart3 } from 'lucide-react'

export function Features() {
  const { t } = useLanguage()

  const features = [
    { icon: Link2, title: t('feat1_title'), desc: t('feat1_desc') },
    { icon: Package, title: t('feat2_title'), desc: t('feat2_desc') },
    { icon: QrCode, title: t('feat3_title'), desc: t('feat3_desc') },
    { icon: FileText, title: t('feat4_title'), desc: t('feat4_desc') },
    { icon: MessageCircle, title: t('feat5_title'), desc: t('feat5_desc') },
    { icon: BarChart3, title: t('feat6_title'), desc: t('feat6_desc') },
  ]

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-background" aria-labelledby="feat-heading">
      <div className="container mx-auto px-4 lg:px-6">
        <h2 id="feat-heading" className="font-serif text-2xl sm:text-3xl font-bold mb-2 text-foreground">
          {t('feat_title')}
        </h2>
        <p className="text-muted-foreground mb-8 sm:mb-10 text-sm sm:text-base lg:text-lg">{t('feat_sub')}</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          {features.map((feat, i) => (
            <div
              key={i}
              className="bg-card rounded-xl sm:rounded-2xl p-5 sm:p-6 border border-border transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5"
            >
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg sm:rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-3 sm:mb-4">
                <feat.icon className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <h4 className="font-semibold text-sm sm:text-base text-foreground mb-1 sm:mb-1.5">{feat.title}</h4>
              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">{feat.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
