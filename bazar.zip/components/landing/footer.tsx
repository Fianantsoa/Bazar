'use client'

import { useLanguage } from '@/hooks/use-language'
import Link from 'next/link'

export function Footer() {
  const { t } = useLanguage()

  return (
    <footer className="bg-secondary py-8 sm:py-10" role="contentinfo">
      <div className="container mx-auto px-4 lg:px-6 flex flex-col items-center gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg bg-primary flex items-center justify-center font-serif text-lg sm:text-xl font-black text-primary-foreground">
            B
          </div>
          <span className="font-serif text-lg sm:text-xl font-bold text-secondary-foreground">
            bazar<small className="text-muted-foreground text-xs ml-0.5">.app</small>
          </span>
        </div>

        <nav className="flex flex-wrap gap-4 sm:gap-5 justify-center" aria-label="Liens du pied de page">
          <Link href="#" className="text-primary text-xs sm:text-sm hover:text-secondary-foreground transition-colors">
            Confidentialite
          </Link>
          <Link href="#" className="text-primary text-xs sm:text-sm hover:text-secondary-foreground transition-colors">
            Conditions
          </Link>
          <Link href="#" className="text-primary text-xs sm:text-sm hover:text-secondary-foreground transition-colors">
            Contact
          </Link>
          <Link href="#" className="text-primary text-xs sm:text-sm hover:text-secondary-foreground transition-colors">
            Blog
          </Link>
        </nav>

        <p className="text-xs sm:text-sm text-muted-foreground text-center">{t('footer_text')}</p>
      </div>
    </footer>
  )
}
