'use client'

import { useLanguage } from '@/hooks/use-language'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Check, X, Info, ArrowRight } from 'lucide-react'

export function Pricing() {
  const { t } = useLanguage()

  const timeline = [
    { num: 1, label: t('ptl_1_label'), sub: t('ptl_1_sub'), type: 'trial' },
    { num: 2, label: t('ptl_2_label'), sub: t('ptl_2_sub'), type: 'trial' },
    { num: 3, label: t('ptl_3_label'), sub: t('ptl_3_sub'), type: 'remind' },
    { num: 4, label: t('ptl_4_label'), sub: t('ptl_4_sub'), type: 'paid' },
  ]

  const trialFeatures = [
    t('trial_li1'),
    t('trial_li2'),
    t('trial_li3'),
    t('trial_li4'),
    t('trial_li5'),
    t('trial_li6'),
  ]

  const starterFeatures = [
    { text: t('starter_li1'), active: true },
    { text: t('starter_li2'), active: true },
    { text: t('starter_li3'), active: true },
    { text: t('starter_li4'), active: true },
    { text: t('starter_li5'), active: true },
    { text: t('starter_li6'), active: false },
    { text: t('starter_li7'), active: false },
  ]

  const proFeatures = [
    t('pro_li1'),
    t('pro_li2'),
    t('pro_li3'),
    t('pro_li4'),
    t('pro_li5'),
    t('pro_li6'),
  ]

  return (
    <section id="pricing" className="py-12 sm:py-16 lg:py-20 bg-secondary" aria-labelledby="pricing-heading">
      <div className="container mx-auto px-4 lg:px-6">
        <h2 id="pricing-heading" className="font-serif text-2xl sm:text-3xl font-bold mb-2 text-secondary-foreground">
          {t('pricing_title')}
        </h2>
        <p className="text-muted-foreground mb-6 sm:mb-8 text-sm sm:text-base lg:text-lg">{t('pricing_sub')}</p>

        {/* Timeline - Hidden on very small screens, simplified on mobile */}
        <div className="bg-card border border-border rounded-xl sm:rounded-2xl p-4 sm:p-5 mb-6 sm:mb-8">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-2 lg:gap-4">
            {timeline.map((step, i) => (
              <div key={i} className="text-center px-1 sm:px-2">
                <div
                  className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full mx-auto mb-2 flex items-center justify-center text-xs sm:text-sm font-bold border ${
                    step.type === 'trial'
                      ? 'bg-primary/20 text-primary border-primary/40'
                      : step.type === 'remind'
                        ? 'bg-blue-500/15 text-blue-600 border-blue-500/30'
                        : 'bg-accent/15 text-accent border-accent/30'
                  }`}
                >
                  {step.num}
                </div>
                <div className="text-xs sm:text-sm font-semibold text-foreground">{step.label}</div>
                <div className="text-[10px] sm:text-xs text-muted-foreground mt-0.5">{step.sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 sm:mb-6">
          {/* Trial */}
          <article className="bg-primary/10 border-2 border-primary/50 rounded-xl sm:rounded-2xl p-5 sm:p-7 flex flex-col" aria-label="Essai gratuit 14 jours">
            <Badge className="self-start mb-2 sm:mb-3 bg-primary text-primary-foreground border-none text-xs">
              {t('trial_badge')}
            </Badge>
            <div className="font-serif text-3xl sm:text-4xl font-bold text-primary">{t('trial_price')}</div>
            <div className="text-xs sm:text-sm text-muted-foreground mb-2 sm:mb-3">{t('trial_period')}</div>
            <p className="text-xs sm:text-sm text-muted-foreground pb-3 sm:pb-4 border-b border-border mb-3 sm:mb-4">
              {t('trial_desc')}
            </p>
            <ul className="space-y-2 sm:space-y-2.5 flex-1 mb-4 sm:mb-5">
              {trialFeatures.map((feat, i) => (
                <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-foreground">
                  <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                  {feat}
                </li>
              ))}
            </ul>
            <Button size="lg" className="w-full text-sm sm:text-base" asChild>
              <a href="#signup">
                {t('trial_cta')}
                <ArrowRight className="w-4 h-4 ml-2" />
              </a>
            </Button>
          </article>

          {/* Starter */}
          <article className="bg-card border border-border rounded-xl sm:rounded-2xl p-5 sm:p-7 flex flex-col relative" aria-label="Plan Starter">
            <Badge className="absolute -top-2.5 sm:-top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground border-none whitespace-nowrap text-[10px] sm:text-xs">
              {t('starter_auto_badge')}
            </Badge>
            <div className="text-[10px] sm:text-xs font-bold tracking-wider text-muted-foreground uppercase mb-1">
              {t('starter_name')}
            </div>
            <div className="font-serif text-3xl sm:text-4xl font-bold text-foreground">{t('starter_price')}</div>
            <div className="text-xs sm:text-sm text-muted-foreground mb-2 sm:mb-3">{t('starter_period')}</div>
            <p className="text-xs sm:text-sm text-muted-foreground pb-3 sm:pb-4 border-b border-border mb-3 sm:mb-4">
              {t('starter_desc')}
            </p>
            <ul className="space-y-2 sm:space-y-2.5 flex-1 mb-4 sm:mb-5">
              {starterFeatures.map((feat, i) => (
                <li
                  key={i}
                  className={`flex items-start gap-2 text-xs sm:text-sm ${feat.active ? 'text-foreground' : 'text-muted-foreground/40 line-through'}`}
                >
                  {feat.active ? (
                    <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                  ) : (
                    <X className="w-4 h-4 text-muted-foreground/40 flex-shrink-0 mt-0.5" />
                  )}
                  {feat.text}
                </li>
              ))}
            </ul>
            <Button
              size="lg"
              variant="secondary"
              className="w-full text-sm sm:text-base bg-secondary text-secondary-foreground border border-border hover:bg-muted"
              asChild
            >
              <a href="#signup">{t('starter_cta')}</a>
            </Button>
          </article>

          {/* Pro */}
          <article className="bg-card border border-border rounded-xl sm:rounded-2xl p-5 sm:p-7 flex flex-col" aria-label="Plan Pro">
            <div className="text-[10px] sm:text-xs font-bold tracking-wider text-muted-foreground uppercase mb-1">
              {t('pro_name')}
            </div>
            <div className="font-serif text-3xl sm:text-4xl font-bold text-foreground">{t('pro_price')}</div>
            <div className="text-xs sm:text-sm text-muted-foreground mb-2 sm:mb-3">{t('pro_period')}</div>
            <p className="text-xs sm:text-sm text-muted-foreground pb-3 sm:pb-4 border-b border-border mb-3 sm:mb-4">
              {t('pro_desc')}
            </p>
            <ul className="space-y-2 sm:space-y-2.5 flex-1 mb-4 sm:mb-5">
              {proFeatures.map((feat, i) => (
                <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-foreground">
                  <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                  {feat}
                </li>
              ))}
            </ul>
            <Button
              size="lg"
              variant="secondary"
              className="w-full text-sm sm:text-base bg-secondary text-secondary-foreground border border-border hover:bg-muted"
              asChild
            >
              <a href="#signup">{t('pro_cta')}</a>
            </Button>
          </article>
        </div>

        {/* Notice */}
        <div className="flex items-start gap-2 sm:gap-3 bg-primary/10 border border-primary/20 rounded-lg sm:rounded-xl p-3 sm:p-4 text-xs sm:text-sm text-foreground leading-relaxed">
          <Info className="w-4 h-4 sm:w-5 sm:h-5 text-primary flex-shrink-0 mt-0.5" />
          <span>{t('pricing_note')}</span>
        </div>
      </div>
    </section>
  )
}
