'use client'

import { Button } from '@/components/ui/button'
import { useLanguage } from '@/hooks/use-language'
import { Menu, X } from 'lucide-react'
import { useState } from 'react'
import Link from 'next/link'

export function Topbar() {
  const { lang, setLang, t } = useLanguage()
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-card/95 backdrop-blur-md border-b border-border">
      <div className="container mx-auto flex items-center justify-between py-3 px-4 lg:px-6">
        <Link href="/" className="flex items-center gap-2.5" aria-label="Bazar.app — retour a l'accueil">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center font-serif text-xl font-black text-primary-foreground">
            B
          </div>
          <span className="font-serif text-xl font-bold text-foreground">
            bazar<small className="text-muted-foreground text-xs ml-0.5">.app</small>
          </span>
        </Link>

        <nav className="flex items-center gap-2" aria-label="Navigation principale">
          <Button
            variant="outline"
            size="sm"
            className="min-w-[50px] text-xs"
            onClick={() => setLang(lang === 'fr' ? 'en' : 'fr')}
            aria-label="Changer de langue"
          >
            {lang === 'fr' ? 'EN' : 'FR'}
          </Button>

          <div className="hidden md:flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <a href="#how">{t('nav_how')}</a>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <a href="#pricing">{t('nav_pricing')}</a>
            </Button>
            <Button size="sm" asChild>
              <a href="#signup">{t('nav_start')}</a>
            </Button>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Menu"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </nav>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-border bg-card p-4 flex flex-col gap-2">
          <Button variant="ghost" className="justify-start" asChild onClick={() => setMobileOpen(false)}>
            <a href="#how">{t('nav_how')}</a>
          </Button>
          <Button variant="ghost" className="justify-start" asChild onClick={() => setMobileOpen(false)}>
            <a href="#pricing">{t('nav_pricing')}</a>
          </Button>
          <Button className="justify-start" asChild onClick={() => setMobileOpen(false)}>
            <a href="#signup">{t('nav_start')}</a>
          </Button>
        </div>
      )}
    </header>
  )
}
