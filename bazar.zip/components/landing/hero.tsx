'use client'

import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useLanguage } from '@/hooks/use-language'
import { Copy, Check, Facebook, MessageCircle } from 'lucide-react'
import { useState } from 'react'

function MockupCard() {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    setCopied(true)
    setTimeout(() => setCopied(false), 1200)
  }

  return (
    <div className="bg-card rounded-2xl p-4 sm:p-5 shadow-2xl w-full max-w-[420px]">
      <div className="flex items-center gap-3 mb-4 pb-4 border-b border-border">
        <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center font-bold text-primary-foreground">
          R
        </div>
        <div className="flex-1">
          <div className="font-bold text-sm text-foreground">Boutique Rachna</div>
          <div className="text-xs text-muted-foreground">45 produits - En ligne</div>
        </div>
        <Badge variant="secondary" className="bg-accent/20 text-accent border-accent/30 text-xs">
          <span className="w-1.5 h-1.5 rounded-full bg-accent mr-1.5" aria-hidden="true" />
          Live
        </Badge>
      </div>

      <div className="flex gap-3 mb-4">
        <div className="w-16 h-16 sm:w-[72px] sm:h-[72px] rounded-xl bg-muted flex items-center justify-center text-2xl sm:text-3xl flex-shrink-0">
          <span aria-hidden="true">{"👗"}</span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-semibold text-foreground mb-1 truncate">Robe Sakalava Premium</div>
          <div className="font-serif text-lg font-bold text-foreground mb-2">45 000 Ar</div>
          <div className="flex items-center gap-2 bg-muted rounded-lg px-2 sm:px-2.5 py-1.5">
            <span className="text-sm" aria-hidden="true">{"🔗"}</span>
            <span className="text-xs text-muted-foreground font-mono flex-1 truncate">bazar.app/p/Ab3kZ</span>
            <Button
              size="sm"
              variant="default"
              className="h-6 px-2 text-xs flex-shrink-0"
              onClick={handleCopy}
            >
              {copied ? <Check className="w-3 h-3" /> : 'Copier'}
            </Button>
          </div>
        </div>
      </div>

      <div className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">
        {"Commandes aujourd'hui"}
      </div>
      <div className="space-y-1">
        {[
          { name: 'Haingo M.', product: 'Robe Sakalava', status: 'Nouvelle', color: 'bg-amber-400', statusBg: 'bg-amber-100 text-amber-800' },
          { name: 'Vola R.', product: 'T-shirt Premium', status: 'Confirmee', color: 'bg-blue-500', statusBg: 'bg-blue-100 text-blue-800' },
          { name: 'Fanja T.', product: 'Sac cuir', status: 'Livree', color: 'bg-accent', statusBg: 'bg-accent/20 text-accent' },
        ].map((order, i) => (
          <div key={i} className="flex items-center gap-2 text-xs text-foreground py-1.5 border-b border-border last:border-0">
            <span className={`w-2 h-2 rounded-full ${order.color} flex-shrink-0`} aria-hidden="true" />
            <span className="flex-1 truncate">{order.name} - {order.product}</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold flex-shrink-0 ${order.statusBg}`}>
              {order.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

export function Hero() {
  const { t } = useLanguage()

  return (
    <section className="bg-secondary text-secondary-foreground overflow-hidden" aria-labelledby="hero-heading">
      <div className="container mx-auto px-4 lg:px-6 pt-12 sm:pt-16 pb-0 lg:pt-20">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center pb-10 sm:pb-14">
          <div>
            <Badge 
              variant="outline" 
              className="mb-4 sm:mb-5 bg-primary/10 border-primary/30 text-primary uppercase tracking-wider text-xs font-bold px-3 sm:px-4 py-1.5"
            >
              {t('hero_badge')}
            </Badge>

            <h1 id="hero-heading" className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-[52px] font-black leading-tight mb-3 sm:mb-4 text-balance">
              <span>{t('hero_title_1')}</span>
              <br />
              <em className="text-primary not-italic">{t('hero_title_2')}</em>
              <span>{t('hero_title_3')}</span>
            </h1>

            <p className="text-secondary-foreground/80 text-sm sm:text-base lg:text-lg leading-relaxed mb-5 sm:mb-7 max-w-xl">
              {t('hero_sub')}
            </p>

            <div className="flex flex-col sm:flex-row gap-3 mb-6 sm:mb-9">
              <Button size="lg" className="text-sm sm:text-base w-full sm:w-auto" asChild>
                <a href="#signup">{t('hero_cta1')}</a>
              </Button>
              <Button 
                size="lg" 
                variant="secondary" 
                className="text-sm sm:text-base w-full sm:w-auto bg-card text-foreground border border-border hover:bg-muted"
                asChild
              >
                <a href="#how">{t('hero_cta2')}</a>
              </Button>
            </div>

            <div className="flex flex-wrap items-center justify-start gap-x-1 gap-y-2 pt-5 sm:pt-7 border-t border-secondary-foreground/10" aria-label="Chiffres cles">
              {[
                { n: t('stat_1n'), l: t('stat_1l') },
                { n: t('stat_2n'), l: t('stat_2l') },
                { n: t('stat_3n'), l: t('stat_3l') },
              ].map((stat, i) => (
                <div key={i} className="flex items-center">
                  {i > 0 && <div className="w-px h-7 sm:h-9 bg-secondary-foreground/15 mx-2 sm:mx-4" aria-hidden="true" />}
                  <div className="text-center px-1 sm:px-2">
                    <div className="font-serif text-lg sm:text-xl lg:text-2xl font-bold text-primary">{stat.n}</div>
                    <div className="text-[10px] sm:text-xs text-secondary-foreground/60 mt-0.5">{stat.l}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <aside className="flex justify-center lg:justify-end" aria-label="Apercu de l'interface">
            <MockupCard />
          </aside>
        </div>
      </div>

      <div className="border-t border-secondary-foreground/10 py-4 sm:py-5" aria-label="Plateformes compatibles">
        <div className="container mx-auto px-4 lg:px-6 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
          <span className="text-xs sm:text-sm text-secondary-foreground/50">{t('proof_label')}</span>
          <div className="flex flex-wrap gap-2 justify-center">
            {[
              { icon: <Facebook className="w-3.5 h-3.5" />, label: 'Facebook' },
              { icon: <span className="text-sm">{"🎵"}</span>, label: 'TikTok' },
              { icon: <MessageCircle className="w-3.5 h-3.5" />, label: 'WhatsApp' },
              { icon: <span className="text-sm">{"📸"}</span>, label: 'Instagram' },
            ].map((chip, i) => (
              <span 
                key={i} 
                className="flex items-center gap-1.5 px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-full text-xs sm:text-sm font-semibold bg-secondary-foreground/10 border border-secondary-foreground/15 text-secondary-foreground/80"
              >
                {chip.icon}
                {chip.label}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
