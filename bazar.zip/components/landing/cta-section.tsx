'use client'

import { useLanguage } from '@/hooks/use-language'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ArrowRight } from 'lucide-react'
import { useState } from 'react'

export function CtaSection() {
  const { t } = useLanguage()
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !email.includes('@')) {
      setError(true)
      setTimeout(() => setError(false), 1800)
      return
    }
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 2500)
    console.log('Signup:', email)
  }

  return (
    <section id="signup" className="py-12 sm:py-16 lg:py-20 bg-background" aria-labelledby="cta-heading">
      <div className="container mx-auto px-4 lg:px-6 max-w-xl text-center">
        <h2 id="cta-heading" className="font-serif text-2xl sm:text-3xl md:text-4xl font-black text-foreground mb-2 sm:mb-3 text-balance">
          {t('cta_title')}
        </h2>
        <p className="text-muted-foreground text-sm sm:text-base lg:text-lg mb-6 sm:mb-8">{t('cta_sub')}</p>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3 justify-center" role="form" aria-label="Inscription rapide">
          <Input
            type="email"
            placeholder={t('cta_placeholder')}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className={`w-full h-11 sm:h-12 text-sm sm:text-base ${error ? 'border-destructive ring-destructive/30 ring-2' : ''}`}
            aria-label="Adresse email"
          />
          <Button type="submit" size="lg" className="h-11 sm:h-12 text-sm sm:text-base w-full" disabled={submitted}>
            {submitted ? (
              <>
                <span className="mr-2">{"✓"}</span>
                {"C'est parti !"}
              </>
            ) : (
              <>
                {t('cta_btn')}
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        </form>

        <p className="mt-3 sm:mt-4 text-xs sm:text-sm text-muted-foreground">{t('cta_hint')}</p>
      </div>
    </section>
  )
}
