"use client"

import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export function OrderHeader() {
  return (
    <header className="sticky top-0 z-10 bg-secondary px-4 py-3.5">
      <div className="mx-auto flex max-w-lg items-center">
        <Link
          href="#"
          className="flex items-center gap-2 rounded-lg border border-secondary-foreground/20 bg-secondary-foreground/10 px-3 py-2 text-sm font-medium text-secondary-foreground transition-colors hover:bg-secondary-foreground/15"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>Retour</span>
        </Link>
        <h1 className="flex-1 text-center text-base font-semibold text-secondary-foreground">
          Passer commande
        </h1>
        <div className="w-[76px]" aria-hidden="true" />
      </div>
    </header>
  )
}
