"use client"

import { User, Phone, MapPin, MessageSquare } from "lucide-react"
import { cn } from "@/lib/utils"

interface FormFieldProps {
  id: string
  label: string
  icon: React.ReactNode
  required?: boolean
  error?: string
  children: React.ReactNode
}

function FormField({ id, label, icon, required, error, children }: FormFieldProps) {
  return (
    <div className={cn("border-b border-border px-4 py-4 last:border-b-0", error && "bg-destructive/5")}>
      <label
        htmlFor={id}
        className={cn(
          "mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide",
          error ? "text-destructive" : "text-muted-foreground"
        )}
      >
        {icon}
        {label}
        {required && <span className="text-destructive">*</span>}
      </label>
      {children}
      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
    </div>
  )
}

interface CustomerFormProps {
  values: {
    name: string
    phone: string
    address: string
    note: string
  }
  errors: {
    name?: string
    phone?: string
    address?: string
  }
  onChange: (field: string, value: string) => void
}

export function CustomerForm({ values, errors, onChange }: CustomerFormProps) {
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <FormField
        id="f-nom"
        label="Nom complet"
        icon={<User className="h-3.5 w-3.5" />}
        required
        error={errors.name}
      >
        <input
          id="f-nom"
          type="text"
          value={values.name}
          onChange={(e) => onChange("name", e.target.value)}
          placeholder="Ex : Miora Rakoto"
          autoComplete="name"
          className="w-full bg-transparent text-base text-card-foreground placeholder:text-muted-foreground/60 focus:outline-none"
        />
      </FormField>

      <FormField
        id="f-tel"
        label="Numéro de téléphone"
        icon={<Phone className="h-3.5 w-3.5" />}
        required
        error={errors.phone}
      >
        <input
          id="f-tel"
          type="tel"
          value={values.phone}
          onChange={(e) => onChange("phone", e.target.value)}
          placeholder="034 XX XXX XX"
          autoComplete="tel"
          className="w-full bg-transparent text-base text-card-foreground placeholder:text-muted-foreground/60 focus:outline-none"
        />
      </FormField>

      <FormField
        id="f-adr"
        label="Adresse de livraison"
        icon={<MapPin className="h-3.5 w-3.5" />}
        required
        error={errors.address}
      >
        <input
          id="f-adr"
          type="text"
          value={values.address}
          onChange={(e) => onChange("address", e.target.value)}
          placeholder="Quartier, ville, commune…"
          autoComplete="street-address"
          className="w-full bg-transparent text-base text-card-foreground placeholder:text-muted-foreground/60 focus:outline-none"
        />
      </FormField>

      <FormField
        id="f-note"
        label="Note ou message"
        icon={<MessageSquare className="h-3.5 w-3.5" />}
      >
        <textarea
          id="f-note"
          value={values.note}
          onChange={(e) => onChange("note", e.target.value)}
          placeholder="Précisions sur la livraison, demandes spéciales…"
          rows={3}
          className="w-full resize-none bg-transparent text-base leading-relaxed text-card-foreground placeholder:text-muted-foreground/60 focus:outline-none"
        />
      </FormField>
    </div>
  )
}
