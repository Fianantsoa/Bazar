"use client"

import { cn } from "@/lib/utils"

interface VariantOption {
  value: string
  label: string
}

interface VariantSelectorProps {
  label: string
  options: VariantOption[]
  value: string
  onChange: (value: string) => void
}

export function VariantSelector({ label, options, value, onChange }: VariantSelectorProps) {
  return (
    <div className="py-4">
      <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            className={cn(
              "rounded-lg border px-4 py-2.5 text-sm font-medium transition-all duration-200",
              value === option.value
                ? "border-secondary bg-secondary text-secondary-foreground shadow-sm"
                : "border-border bg-card text-card-foreground hover:border-secondary/50 hover:bg-muted"
            )}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  )
}
