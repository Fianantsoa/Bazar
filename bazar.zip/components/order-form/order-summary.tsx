"use client"

interface OrderSummaryProps {
  articleDescription: string
  unitPrice: number
  quantity: number
}

export function OrderSummary({ articleDescription, unitPrice, quantity }: OrderSummaryProps) {
  const formattedUnitPrice = unitPrice.toLocaleString("fr-FR") + " Ar"
  const total = unitPrice * quantity
  const formattedTotal = total.toLocaleString("fr-FR") + " Ar"

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="divide-y divide-border">
        <div className="flex items-center justify-between px-4 py-3.5">
          <span className="text-sm text-muted-foreground">Article</span>
          <span className="text-sm font-medium text-card-foreground">{articleDescription}</span>
        </div>
        <div className="flex items-center justify-between px-4 py-3.5">
          <span className="text-sm text-muted-foreground">Prix unitaire</span>
          <span className="text-sm font-medium text-card-foreground">{formattedUnitPrice}</span>
        </div>
        <div className="flex items-center justify-between px-4 py-3.5">
          <span className="text-sm text-muted-foreground">Quantité</span>
          <span className="text-sm font-medium text-card-foreground">× {quantity}</span>
        </div>
      </div>
      <div className="flex items-center justify-between border-t-2 border-border bg-muted/30 px-4 py-4">
        <span className="text-base font-semibold text-card-foreground">Total estimé</span>
        <span className="text-xl font-bold text-secondary">{formattedTotal}</span>
      </div>
    </div>
  )
}
