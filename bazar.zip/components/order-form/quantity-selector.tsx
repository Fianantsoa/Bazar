"use client"

import { Minus, Plus } from "lucide-react"
import { cn } from "@/lib/utils"

interface QuantitySelectorProps {
  value: number
  max: number
  onChange: (value: number) => void
}

export function QuantitySelector({ value, max, onChange }: QuantitySelectorProps) {
  const decrease = () => {
    if (value > 1) onChange(value - 1)
  }

  const increase = () => {
    if (value < max) onChange(value + 1)
  }

  return (
    <div className="flex items-center justify-between py-4">
      <div>
        <p className="text-sm font-medium text-card-foreground">Nombre d&apos;articles</p>
        <p className="mt-0.5 text-xs text-muted-foreground">{max} disponibles</p>
      </div>
      <div className="flex items-center">
        <button
          type="button"
          onClick={decrease}
          disabled={value <= 1}
          aria-label="Diminuer la quantité"
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-l-lg border border-r-0 border-border bg-muted text-card-foreground transition-colors",
            value <= 1 ? "cursor-not-allowed opacity-40" : "hover:bg-border"
          )}
        >
          <Minus className="h-4 w-4" />
        </button>
        <div className="flex h-10 w-14 items-center justify-center border-y border-border bg-card text-sm font-semibold text-card-foreground">
          {value}
        </div>
        <button
          type="button"
          onClick={increase}
          disabled={value >= max}
          aria-label="Augmenter la quantité"
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-r-lg border border-l-0 border-border bg-muted text-card-foreground transition-colors",
            value >= max ? "cursor-not-allowed opacity-40" : "hover:bg-border"
          )}
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
