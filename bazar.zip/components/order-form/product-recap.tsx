"use client"

import { Shirt } from "lucide-react"

interface ProductRecapProps {
  name: string
  price: number
  shop: string
}

export function ProductRecap({ name, price, shop }: ProductRecapProps) {
  const formattedPrice = price.toLocaleString("fr-FR") + " Ar"

  return (
    <div className="bg-secondary px-4 pb-6 pt-2">
      <div className="mx-auto flex max-w-lg items-center gap-4">
        <div className="flex h-16 w-16 flex-shrink-0 items-center justify-center rounded-xl border border-primary/30 bg-secondary-foreground/10">
          <Shirt className="h-7 w-7 text-primary" aria-hidden="true" />
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="truncate text-base font-semibold leading-tight text-secondary-foreground">
            {name}
          </h2>
          <p className="mt-1 text-xl font-semibold text-primary">{formattedPrice}</p>
          <p className="mt-0.5 text-xs text-secondary-foreground/60">{shop}</p>
        </div>
      </div>
    </div>
  )
}
