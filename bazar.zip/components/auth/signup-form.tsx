"use client"

import { Divider, GoogleButton } from "./login-form"

interface SignupFormProps {
  onSwitchToLogin: () => void
}

export function SignupForm({ onSwitchToLogin }: SignupFormProps) {
  return (
    <div>
      <h2 className="mb-1 font-serif text-[22px] text-secondary">Cree ta boutique</h2>
      <p className="mb-6 text-[13px] text-muted-foreground">Gratuit · Aucune carte requise</p>

      <form className="space-y-4">
        <div className="flex gap-2">
          <div className="flex-1 space-y-1.5">
            <label htmlFor="signup-firstname" className="block text-xs font-medium tracking-wide text-secondary">
              Prenom
            </label>
            <input
              id="signup-firstname"
              type="text"
              placeholder="Miora"
              className="h-[42px] w-full rounded-lg border border-border bg-card px-3 font-sans text-sm text-secondary outline-none transition-all placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/15"
            />
          </div>
          <div className="flex-1 space-y-1.5">
            <label htmlFor="signup-lastname" className="block text-xs font-medium tracking-wide text-secondary">
              Nom
            </label>
            <input
              id="signup-lastname"
              type="text"
              placeholder="Rakoto"
              className="h-[42px] w-full rounded-lg border border-border bg-card px-3 font-sans text-sm text-secondary outline-none transition-all placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/15"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label htmlFor="signup-shop" className="block text-xs font-medium tracking-wide text-secondary">
            Nom de ta boutique
          </label>
          <input
            id="signup-shop"
            type="text"
            placeholder="ex: Mode Miora"
            className="h-[42px] w-full rounded-lg border border-border bg-card px-3 font-sans text-sm text-secondary outline-none transition-all placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/15"
          />
        </div>

        <div className="space-y-1.5">
          <label htmlFor="signup-email" className="block text-xs font-medium tracking-wide text-secondary">
            Email
          </label>
          <input
            id="signup-email"
            type="email"
            placeholder="toi@exemple.com"
            className="h-[42px] w-full rounded-lg border border-border bg-card px-3 font-sans text-sm text-secondary outline-none transition-all placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/15"
          />
        </div>

        <div className="space-y-1.5">
          <label htmlFor="signup-password" className="block text-xs font-medium tracking-wide text-secondary">
            Mot de passe
          </label>
          <input
            id="signup-password"
            type="password"
            placeholder="8 caracteres minimum"
            className="h-[42px] w-full rounded-lg border border-border bg-card px-3 font-sans text-sm text-secondary outline-none transition-all placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/15"
          />
        </div>

        <button
          type="submit"
          className="h-11 w-full rounded-lg bg-primary font-sans text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
        >
          Creer ma boutique gratuitement
        </button>
      </form>

      <Divider />

      <GoogleButton text="S'inscrire avec Google" />

      <p className="mt-5 text-center text-xs text-muted-foreground">
        Deja un compte ?{" "}
        <button onClick={onSwitchToLogin} className="font-medium text-primary hover:underline">
          Se connecter
        </button>
      </p>

      <p className="mt-4 text-center text-[11px] leading-relaxed text-muted-foreground/60">
        En creant un compte, tu acceptes nos{" "}
        <a href="#" className="text-muted-foreground hover:underline">
          conditions d&apos;utilisation
        </a>{" "}
        et notre{" "}
        <a href="#" className="text-muted-foreground hover:underline">
          politique de confidentialite
        </a>
        .
      </p>
    </div>
  )
}
