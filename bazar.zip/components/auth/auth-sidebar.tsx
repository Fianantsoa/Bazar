"use client"

export function AuthSidebar() {
  return (
    <div className="relative flex flex-1 flex-col justify-between overflow-hidden bg-secondary p-10">
      {/* Decorative circles */}
      <div 
        className="absolute -right-[60px] -top-[60px] h-[260px] w-[260px] rounded-full border border-primary/15" 
        aria-hidden="true"
      />
      <div 
        className="absolute -bottom-[40px] -left-[40px] h-[180px] w-[180px] rounded-full border border-primary/10" 
        aria-hidden="true"
      />

      {/* Logo */}
      <div className="flex items-center gap-2.5">
        <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-[10px] bg-primary font-serif text-[26px] font-bold text-secondary">
          B
        </div>
        <span className="font-serif text-2xl text-secondary-foreground">
          bazar<span className="text-primary">.app</span>
        </span>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-1 flex-col justify-center py-4">
        <h1 className="mb-4 font-serif text-[28px] leading-tight text-secondary-foreground">
          Ta boutique en ligne,
          <br />
          <span className="text-primary">en 5 minutes.</span>
        </h1>
        <p className="max-w-[260px] text-sm leading-relaxed text-secondary-foreground/55">
          Cree ton shop, partage tes produits sur Facebook & TikTok, recois tes commandes.
        </p>
        
        <div className="mt-6 flex flex-col gap-2.5">
          <FeatureItem>Liens produit partageables en 1 clic</FeatureItem>
          <FeatureItem>Gestion des commandes simplifiee</FeatureItem>
          <FeatureItem>QR code & catalogue PDF automatique</FeatureItem>
          <FeatureItem>Notifications WhatsApp client</FeatureItem>
        </div>
      </div>

      {/* Footer */}
      <p className="relative z-10 text-xs text-secondary-foreground/30">
        © 2025 Bazar.app · Made in Madagascar
      </p>
    </div>
  )
}

function FeatureItem({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2.5 text-[13px] text-secondary-foreground/70">
      <div className="h-1.5 w-1.5 flex-shrink-0 rounded-full bg-primary" aria-hidden="true" />
      {children}
    </div>
  )
}
