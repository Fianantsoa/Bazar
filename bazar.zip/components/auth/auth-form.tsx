"use client"

import { useState } from "react"
import { LoginForm } from "./login-form"
import { SignupForm } from "./signup-form"

type AuthTab = "login" | "signup"

export function AuthForm() {
  const [activeTab, setActiveTab] = useState<AuthTab>("login")

  return (
    <div className="w-full max-w-[340px]">
      {/* Tab Row */}
      <div className="mb-8 flex rounded-[10px] bg-secondary/7 p-1">
        <button
          onClick={() => setActiveTab("login")}
          className={`flex-1 rounded-[7px] py-2 text-[13px] font-medium transition-all duration-150 ${
            activeTab === "login"
              ? "bg-card text-secondary shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          Connexion
        </button>
        <button
          onClick={() => setActiveTab("signup")}
          className={`flex-1 rounded-[7px] py-2 text-[13px] font-medium transition-all duration-150 ${
            activeTab === "signup"
              ? "bg-card text-secondary shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          Inscription
        </button>
      </div>

      {/* Form Panels */}
      {activeTab === "login" ? (
        <LoginForm onSwitchToSignup={() => setActiveTab("signup")} />
      ) : (
        <SignupForm onSwitchToLogin={() => setActiveTab("login")} />
      )}
    </div>
  )
}
