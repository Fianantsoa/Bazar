"use client"

interface LoginFormProps {
  onSwitchToSignup: () => void
}

export function LoginForm({ onSwitchToSignup }: LoginFormProps) {
  return (
    <div>
      <h2 className="mb-1 font-serif text-[22px] text-secondary">Bon retour</h2>
      <p className="mb-6 text-[13px] text-muted-foreground">Connecte-toi a ta boutique</p>

      <form className="space-y-4">
        <div className="space-y-1.5">
          <label htmlFor="login-email" className="block text-xs font-medium tracking-wide text-secondary">
            Adresse email
          </label>
          <input
            id="login-email"
            type="email"
            placeholder="toi@exemple.com"
            className="h-[42px] w-full rounded-lg border border-border bg-card px-3 font-sans text-sm text-secondary outline-none transition-all placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/15"
          />
        </div>

        <div className="space-y-1.5">
          <label htmlFor="login-password" className="block text-xs font-medium tracking-wide text-secondary">
            Mot de passe
          </label>
          <input
            id="login-password"
            type="password"
            placeholder="••••••••"
            className="h-[42px] w-full rounded-lg border border-border bg-card px-3 font-sans text-sm text-secondary outline-none transition-all placeholder:text-muted-foreground/60 focus:border-primary focus:ring-2 focus:ring-primary/15"
          />
        </div>

        <a href="#" className="-mt-1 block text-right text-xs text-primary hover:underline">
          Mot de passe oublie ?
        </a>

        <button
          type="submit"
          className="h-11 w-full rounded-lg bg-primary font-sans text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
        >
          Se connecter
        </button>
      </form>

      <Divider />

      <GoogleButton text="Continuer avec Google" />

      <p className="mt-5 text-center text-xs text-muted-foreground">
        Pas encore de compte ?{" "}
        <button onClick={onSwitchToSignup} className="font-medium text-primary hover:underline">
          Creer ma boutique
        </button>
      </p>
    </div>
  )
}

function Divider() {
  return (
    <div className="my-5 flex items-center gap-2.5 text-xs text-muted-foreground/60">
      <div className="h-px flex-1 bg-border" />
      ou
      <div className="h-px flex-1 bg-border" />
    </div>
  )
}

function GoogleButton({ text }: { text: string }) {
  return (
    <button
      type="button"
      className="flex h-[42px] w-full items-center justify-center gap-2 rounded-lg border border-border bg-card font-sans text-[13px] font-medium text-secondary transition-colors hover:border-secondary"
    >
      <div className="flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[9px] font-bold text-primary-foreground">
        G
      </div>
      {text}
    </button>
  )
}

export { Divider, GoogleButton }
