'use client'

import { Truck } from 'lucide-react'
import { cn } from '@/lib/utils'

type OrderStatus = 'received' | 'pending' | 'shipping' | 'delivered'

interface TrackingCardProps {
  currentStatus: OrderStatus
}

const steps = [
  { id: 'received', label: 'Recue' },
  { id: 'pending', label: 'En attente confirmation' },
  { id: 'shipping', label: 'En livraison' },
  { id: 'delivered', label: 'Livree' },
] as const

export function TrackingCard({ currentStatus }: TrackingCardProps) {
  const currentIndex = steps.findIndex(s => s.id === currentStatus)

  return (
    <div className="bg-card rounded-2xl p-4 sm:p-5 border border-border/50 animate-[fadeUp_0.4s_0.7s_ease_both]">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-[30px] h-[30px] bg-primary/10 rounded-lg flex items-center justify-center">
          <Truck className="w-4 h-4 text-primary" />
        </div>
        <h2 className="text-sm font-medium text-foreground">Suivi de commande</h2>
      </div>

      <div className="flex items-start" role="list" aria-label="Etapes de la commande">
        {steps.map((step, index) => {
          const isDone = index < currentIndex
          const isActive = index === currentIndex
          const isLast = index === steps.length - 1

          return (
            <div key={step.id} className="flex items-start flex-1" role="listitem">
              <div className="flex flex-col items-center flex-1">
                <div 
                  className={cn(
                    "w-2.5 h-2.5 rounded-full mb-1.5 transition-colors",
                    isDone && "bg-secondary",
                    isActive && "bg-primary",
                    !isDone && !isActive && "bg-border"
                  )}
                  aria-current={isActive ? "step" : undefined}
                />
                <span 
                  className={cn(
                    "text-[10px] text-center leading-tight px-0.5",
                    isDone && "text-secondary font-medium",
                    isActive && "text-primary font-medium",
                    !isDone && !isActive && "text-muted-foreground/60"
                  )}
                >
                  {step.label}
                </span>
              </div>
              {!isLast && (
                <div 
                  className={cn(
                    "h-[1.5px] flex-1 mt-[5px] -mx-1",
                    index < currentIndex ? "bg-secondary" : "bg-border"
                  )}
                  aria-hidden="true"
                />
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
