'use client'

interface HeroConfirmationProps {
  orderNumber: string
}

export function HeroConfirmation({ orderNumber }: HeroConfirmationProps) {
  return (
    <section className="bg-secondary pt-8 pb-10 text-center relative overflow-hidden">
      {/* Check ring with animation */}
      <div className="w-[72px] h-[72px] rounded-full bg-primary/10 border-2 border-primary flex items-center justify-center mx-auto mb-4 animate-[pop_0.4s_cubic-bezier(0.34,1.56,0.64,1)_both]">
        <svg 
          width="32" 
          height="32" 
          viewBox="0 0 32 32" 
          fill="none"
          className="animate-[draw_0.5s_0.3s_ease_both]"
          style={{ strokeDasharray: 40, strokeDashoffset: 0 }}
        >
          <polyline 
            points="7,17 13,23 25,10" 
            stroke="currentColor" 
            strokeWidth="2.5" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            className="text-primary"
          />
        </svg>
      </div>

      <h1 className="font-serif text-2xl sm:text-[26px] text-secondary-foreground mb-1.5 animate-[fadeUp_0.4s_0.2s_ease_both]">
        Commande recue !
      </h1>
      <p className="text-sm text-secondary-foreground/60 animate-[fadeUp_0.4s_0.35s_ease_both]">
        Le vendeur va vous confirmer bientot
      </p>

      <div className="inline-block mt-3.5 bg-secondary-foreground/5 border border-secondary-foreground/10 rounded-lg px-4 py-1.5 text-xs text-secondary-foreground/60 animate-[fadeUp_0.4s_0.45s_ease_both]">
        Commande <span className="text-primary font-medium tracking-wider">{orderNumber}</span>
      </div>

      {/* Bottom curve */}
      <div className="absolute -bottom-px left-0 right-0 h-7 bg-background rounded-t-[28px]" aria-hidden="true" />
    </section>
  )
}
