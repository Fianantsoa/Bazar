'use client'

import { Package } from 'lucide-react'

interface OrderItem {
  name: string
  variant: string
  quantity: number
  price: number
  emoji?: string
}

interface OrderCardProps {
  item: OrderItem
  total: number
}

export function OrderCard({ item, total }: OrderCardProps) {
  const formatPrice = (price: number) => {
    return price.toLocaleString('fr-FR')
  }

  return (
    <div className="bg-card rounded-2xl p-4 sm:p-5 border border-border/50 animate-[fadeUp_0.4s_0.5s_ease_both]">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-[30px] h-[30px] bg-primary/10 rounded-lg flex items-center justify-center">
          <Package className="w-4 h-4 text-primary" />
        </div>
        <h2 className="text-sm font-medium text-foreground">Votre commande</h2>
      </div>

      <div className="flex gap-3 items-center">
        <div className="w-[62px] h-[62px] rounded-xl bg-gradient-to-br from-muted to-muted/80 flex items-center justify-center text-2xl shrink-0">
          {item.emoji || '📦'}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-medium text-foreground mb-0.5 truncate">{item.name}</h3>
          <p className="text-xs text-muted-foreground mb-1.5">{item.variant}</p>
          <div className="flex items-center justify-between">
            <span className="bg-background rounded-md px-2 py-0.5 text-xs text-muted-foreground">
              Qte : {item.quantity}
            </span>
            <span className="text-[15px] font-medium text-foreground">
              {formatPrice(item.price)} <span className="text-xs text-muted-foreground font-normal">Ar</span>
            </span>
          </div>
        </div>
      </div>

      <div className="h-px bg-border/60 my-3" />

      <div className="flex justify-between items-center">
        <span className="text-sm text-muted-foreground">Total a payer</span>
        <span className="text-[17px] font-medium text-foreground">
          {formatPrice(total)} <span className="text-xs text-muted-foreground font-normal">Ar</span>
        </span>
      </div>
    </div>
  )
}
