'use client'

import { MapPin, User, Phone, Home } from 'lucide-react'

interface DeliveryInfo {
  clientName: string
  phone: string
  address: string
}

interface DeliveryCardProps {
  delivery: DeliveryInfo
}

export function DeliveryCard({ delivery }: DeliveryCardProps) {
  const infoItems = [
    { icon: User, label: 'Client', value: delivery.clientName },
    { icon: Phone, label: 'Telephone', value: delivery.phone },
    { icon: Home, label: 'Adresse', value: delivery.address },
  ]

  return (
    <div className="bg-card rounded-2xl p-4 sm:p-5 border border-border/50 animate-[fadeUp_0.4s_0.6s_ease_both]">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-[30px] h-[30px] bg-primary/10 rounded-lg flex items-center justify-center">
          <MapPin className="w-4 h-4 text-primary" />
        </div>
        <h2 className="text-sm font-medium text-foreground">Details de livraison</h2>
      </div>

      <div className="flex flex-col gap-2.5">
        {infoItems.map((item, index) => (
          <div key={index} className="flex items-start gap-2.5">
            <div className="w-7 h-7 bg-background rounded-lg flex items-center justify-center shrink-0 mt-0.5">
              <item.icon className="w-3.5 h-3.5 text-muted-foreground" />
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground/70 mb-0.5">{item.label}</p>
              <p className="text-sm text-foreground">{item.value}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
