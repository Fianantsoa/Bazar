'use client'

import { Button } from '@/components/ui/button'
import { ExternalLink } from 'lucide-react'

interface ActionButtonsProps {
  shopSlug?: string
}

export function ActionButtons({ shopSlug = 'fashion-tana' }: ActionButtonsProps) {
  const handleBrowse = () => {
    window.location.href = `/${shopSlug}`
  }

  const handleShare = async () => {
    const shareData = {
      title: 'Decouvrez cette boutique sur Bazar',
      text: 'Je viens de commander sur cette boutique, regarde leurs produits !',
      url: window.location.origin + '/' + shopSlug,
    }

    if (navigator.share) {
      try {
        await navigator.share(shareData)
      } catch {
        // User cancelled or share failed
      }
    } else {
      // Fallback: copy to clipboard
      await navigator.clipboard.writeText(shareData.url)
      alert('Lien copie !')
    }
  }

  return (
    <div className="space-y-2.5 animate-[fadeUp_0.4s_0.85s_ease_both]">
      <Button 
        onClick={handleBrowse}
        className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground rounded-xl h-12 text-sm font-medium"
      >
        Voir d&apos;autres produits de la boutique
      </Button>
      <Button 
        onClick={handleShare}
        variant="outline"
        className="w-full bg-transparent border-border text-muted-foreground hover:border-muted-foreground/50 rounded-xl h-11 text-sm gap-2"
      >
        Partager cette boutique
        <ExternalLink className="w-3.5 h-3.5" />
      </Button>
    </div>
  )
}
